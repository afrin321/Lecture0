<?php
    require_once('../php/sessionAdminC.php');
?>

<!DOCTYPE html>
<html>
<head>
	<title>Departments</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0"><link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>  
		<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	<link rel="stylesheet" href="../homestyle.css">
</head>
<body>
	
	<div class="container-fluid">
		<ul class="up">
			<li class="left"><img src="../logo.png" class="img-fluid" class="left"></li>
			<li class="up">
				<form action="../php/loginC.php" method="post">
					<input type="submit" class="btn btn-primary logout" name="alog" value="Logout">
				</form>
			</li>			
		</ul>
	</div>

	
	<nav class="navbar menu">
  		<div class="container-fluid">    
		<ul class="menu nav navbar-nav">
		<li class="menu">
			<a href="adminHome.php" class="menu">Home</a>
		</li>
		<li class="menu">
			<a href="adminDept.php" class="menu">Departments</a>
		</li>
		<li class="menu">
			<a href="adminConsultants.php" class="menu">Consultants</a>
		</li>
		<li class="menu">
			<a href="adminPatient.php" class="menu">Patient Info</a>
		</li>
		<li class="menu">
			<a href="conSlot.php" class="menu">Slots</a>
		</li>
		<li class="menu">
			<a href="adminEmp.php" class="menu">Employees</a>
		</li>
		<li class="menu">
			<a href="adminSettings.php" class="menu">Settings</a>
		</li>
	</ul>
	</div>
	</nav>
	<div class="container">
		<h1 class="display-3">Departments</h1>
		<hr>
		Select one of the options from below to view details.<br>
		<br>
			<div class="btn-group btn-group-lg">
				<input type="button" name="" value="View All" class="btn btn-primary" onclick="allDept()">
				<input type="button" name="" value="Search" onclick="searchList()" class="btn btn-primary">
				<input type="button" name="" value="Add Department" onclick="addD()" class="btn btn-primary">
			</div> 
			<br><br>

			<div class="container-fluid" id="allD">

				
			</div>



	</div>
	<br>
	<div>


</div>

	<script type="text/javascript">
		document.getElementById('allD').style.display = "none";

		// function showList(){

		// 	var xhttp = new XMLHttpRequest();
		//  	xhttp.open('POST', '../php/departmentC.php', true);
		// 	xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
		// 	xhttp.send('full_list='+'true');

		// 	xhttp.onreadystatechange = function(){
		// 		if(this.readyState == 4 && this.status == 200){

		// 			document.getElementById('list1').innerHTML = this.responseText;



		// 		}
		// 	}	


		// 	document.getElementById('list1').style.display = "block";
		// }

		function allDept() {
			document.getElementById('allD').style.display = 'none';

			if (document.getElementById('allD').style.display=='block') {
				document.getElementById('allD').style.display = 'none';
			}else{
				document.getElementById('allD').style.display = 'block'; 
			}

			var xhttp2 = new XMLHttpRequest();
		 	xhttp2.open('POST', '../php/departmentC.php', true);
			xhttp2.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp2.send('full_list='+'true');

			xhttp2.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					document.getElementById('allD').innerHTML = this.responseText;

				}
			}

		}

		function searchList() {
			document.getElementById('allD').style.display = 'none';

			if (document.getElementById('allD').style.display=='block') {
				document.getElementById('allD').style.display = 'none';
			}else{
				document.getElementById('allD').style.display = 'block'; 
			}

			document.getElementById('allD').innerHTML = "<select class=\"form-control\" id=\"sel2\" name=\"sellist2\"  onchange=\"changeFunc(value);\"></select><br><br>"+"<div id=\"searchresult\"></div>";


			var xhttp3 = new XMLHttpRequest();
		 	xhttp3.open('POST', '../php/departmentC.php', true);
			xhttp3.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp3.send('searchL='+'true');

			xhttp3.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					document.getElementById('sel2').innerHTML = this.responseText;

				}
			}

		}

		function openL(p) {
			var dname = p;

			var xhttp4 = new XMLHttpRequest();
		 	xhttp4.open('POST', '../php/departmentC.php', true);
			xhttp4.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp4.send('conL='+'true'+'&dept='+dname);



			xhttp4.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					document.getElementById('searchresult').innerHTML = this.responseText;

				}
			}
		}

		function changeFunc(value){

			if (value!="") {
			openL(value);

			}
		}

		function addD() {
			document.getElementById('allD').style.display = 'none';

			if (document.getElementById('allD').style.display=='block') {
				document.getElementById('allD').style.display = 'none';
			}else{
				document.getElementById('allD').style.display = 'block'; 
			}

			document.getElementById('allD').innerHTML = "<div class=\"container-fluid\" id=\"alert1\"></div><br><div class=\"form-group\"><label for=\"usr\">Department Name:</label><input type=\"text\" class=\"form-control\" id=\"usr\" placeholder=\"Department Name\"></div><button type=\"button\" class=\"btn btn-primary\" onclick=\"adddept()\">Add</button>";

		}

		function adddept(){
			var n = document.getElementById('usr').value;

			var xhttp5 = new XMLHttpRequest();
		 	xhttp5.open('POST', '../php/departmentC.php', true);
			xhttp5.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp5.send('new='+'true'+'&dname='+n);

			xhttp5.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					

					if (this.responseText.trim() == 'common') {
						document.getElementById('alert1').innerHTML = "<div class=\"alert alert-warning\"><strong>Warning!</strong> A departemnt with this name already exists.</div>";

					}else if(this.responseText.trim() == 'false') {
						document.getElementById('alert1').innerHTML = "<div class=\"alert alert-warning\"><strong>Warning!</strong> Department name field is empty.</div>";
					}else if(this.responseText.trim() == 'true'){
						document.getElementById('alert1').innerHTML = "<div class=\"alert alert-success\"><strong>Success!</strong> Department created successfully.</div>";

					}else{
						document.getElementById('alert1').innerHTML = "error";
					}

					//document.getElementById('allD').innerHTML = this.responseText;

				}
			}

		}

		function delDept(i){

			var xhttp6 = new XMLHttpRequest();
		 	xhttp6.open('POST', '../php/departmentC.php', true);
			xhttp6.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp6.send('checkd='+i);

			xhttp6.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					

				}
			}		

		}

		function editdept(i){

			document.getElementById('all')

			var xhttp7 = new XMLHttpRequest();
		 	xhttp7.open('POST', '../php/departmentC.php', true);
			xhttp7.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp7.send('editd='+i);


		}

	</script>

	


</body>
</html>