<!DOCTYPE html>
<html>
<head>
	<title>Login page</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	<link rel="stylesheet" href="../loginstyle.css">
</head>
<body>


	<div class="container">	
		<div class="panel panel-primary">
			<div class="panel-heading">
				 <h2 class="text-center">Attendant Login</h2>			 
			</div>
			<div id="c1"></div>
			<div class="panel-body">
				<p>Enter User Id and Password to login.</p> 
			
				<form action="../php/loginC.php" method="post">

					<div class="form-group">
						<label for="uid">User Id:</label>
						<input type="text" id="uid" class="form-control" placeholder="Enter User Id" required>
					</div>
					<div class="form-group">
					    <label for="pw">Password:</label>
					    <input type="password" class="form-control" placeholder="Enter password" id="pw" required>
					</div>

					<input type="button" name="submit" value="Login" class="btn btn-primary" onclick="checkAccnt()"> <label id="stat"></label>
				</form>
			</div>
		</div>
	</div>	
</body>

<script type="text/javascript">

	function checkAccnt(){

		var uid = document.getElementById('uid').value;
		var pw = document.getElementById('pw').value;

		if (uid==''||pw=='') {
			document.getElementById('c1').innerHTML = "<div class=\"alert alert-danger\"><strong>Danger!</strong> Empty/Incorrect Fields Present</div>";
		}else{


		 	var xhttp = new XMLHttpRequest();
		 	xhttp.open('POST', '../../php/loginC.php', true);
			xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp.send('attsubmit='+'true'+'&auid='+uid+'&apw='+pw);

			//document.getElementById('data').innerHTML = this.statusText;

			

			xhttp.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){
					//document.getElementById('data').style.display = "block";

					//document.getElementById('stat').innerHTML =  this.responseText;

					res = this.responseText;
					//document.getElementById('stat').innerHTML =  res;

					if((res=='Invalid entry. Account does not exist.')||(res=='empty')){

						
							document.getElementById('stat').innerHTML =  "<span style=\"color:red\">* Invalid entry. Account does not exist.</span>";
					
					}else{
						//document.getElementById('stat').innerHTML =  res;
						location.replace("attHome.php?error=no");
					}



				}
			}
		}
	}




	
</script>
</html>