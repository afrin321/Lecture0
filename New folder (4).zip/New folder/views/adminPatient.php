<?php
    require_once('../php/sessionAdminC.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0"><link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script> 
	<link rel="stylesheet" href="../homestyle.css">
</head>
<body>

	<div class="container-fluid">
		<ul class="up">
			<li class="left"><img src="../logo.png" class="img-fluid" class="left"></li>
			<li class="up">
				<form action="../php/loginC.php" method="post">
					<input type="submit" class="btn btn-primary logout" name="alog" value="Logout">
				</form>
			</li>			
		</ul>
	</div>
	<nav class="navbar menu">
  		<div class="container-fluid">    
		<ul class="menu nav navbar-nav navbar">
		<li class="menu">
			<a href="adminHome.php" class="menu">Home</a>
		</li>
		<li class="menu">
			<a href="adminDept.php" class="menu">Departments</a>
		</li>
		<li class="menu">
			<a href="adminConsultants.php" class="menu">Consultants</a>
		</li>
		<li class="menu">
			<a href="adminPatient.php" class="menu">Patient Info</a>
		</li>
		<li class="menu">
			<a href="conSlot.php" class="menu">Slots</a>
		</li>
		<li class="menu">
			<a href="adminEmp.php" class="menu">Employees</a>
		</li>
		<li class="menu">
			<a href="adminSettings.php" class="menu">Settings</a>
		</li>
	</ul>
	</div>
	</nav>

	<div class="container">
		<h1 class="display-3">Cancellations</h1>
		<hr>

		<div class="container">
			<h3 class="display-5">Cancel Appointment</h3>
			<hr>
			<h4>Select date or type slot id to cancel appointment. Check thoroughly as cancelled appointments cannot be retrieved.</h4>

			<div class="container-fluid" id="r2"></div>
			<br>
			<div class="form-group">
			  <label for="d1">Date:</label>
			  <input type="date" class="form-control" id="d1">
			</div>
			<input type="button" name="" value="Cancel Day" onclick="cancelDay()" class="btn btn-primary">
			<br>
			<br>
<!-- 			<div class="form-group">
			  <label for="s1">Slot:</label>
			  <input type="text" class="form-control" id="s1" placeholder="Slot ID">
			</div>
			<input type="button" name="" value="Cancel Slot" onclick="cancelSlot()" class="btn btn-primary"> -->
			



			
			

		</div>
		
	</div>

	<script type="text/javascript">
		
		function cancelDay() {



			var d1 = document.getElementById('d1').value;
			var xhttp = new XMLHttpRequest();
		 	xhttp.open('POST', '../php/adminPatientC.php', true);
			xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp.send('canceld='+'true'+'&d1='+d1);

			xhttp.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					if ((this.responseText.trim()=='error')||(this.responseText.trim()=='error day over')) {

						document.getElementById('r2').innerHTML = "<div class=\"alert alert-danger\"><strong>Error!</strong> "+"  "+"Appointment not cancelled."+"</div>";


					}else{		
											
						document.getElementById('r2').innerHTML = "<div class=\"alert alert-success\"><strong>Success!</strong> "+"  "+this.responseText+"</div>";
					
					}

				}
			}
		}

		function cancelSlot(){

			var s1 = document.getElementById('s1').value;
			var xhttp = new XMLHttpRequest();
		 	xhttp.open('POST', '../php/adminPatientC.php', true);
			xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp.send('cancels='+'true'+'&s1='+s1);

			xhttp.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					document.getElementById('r2').innerHTML = this.responseText;

					// if (this.responseText.trim()=='No slots registered.') {
					// 	document.getElementById('r2').innerHTML = this.responseText;
					// }else{
					// 	document.getElementById('r2').innerHTML = "deleted successfully";
					// }

				}
			}

		}
	</script>

	


</body>
</html>