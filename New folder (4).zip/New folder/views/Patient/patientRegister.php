<!DOCTYPE html>
<html>
<head>
	<title>Patient Registration Portal</title>
	   	<meta charset="utf-8">
	  	<meta name="viewport" content="width=device-width, initial-scale=1">
	  	<meta charset="utf-8">
  		<meta name="viewport" content="width=device-width, initial-scale=1">
  		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  
		<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
	<link rel="stylesheet" href="patientLoginStyle.css">
	
</head>
<body>
	<div class="container-fluid">
		<div class="container" id="div1">
			<div class="panel panel-success">
			    <div class="panel-heading"><h1>Patient Registration</h1></div>
				    <div class="panel-body">
				    	<div class="container" id="inf"></div>
				    	<div class="form-group">
						  <label for="pfname">First Name:</label><label id="fn"></label>
						  <input type="text" class="form-control" id="pfname" placeholder="First Name">
						</div>
						<div class="form-group">
						  <label for="psname">Last Name:</label><label id="sn"></label>
						  <input type="text" class="form-control" id="psname" placeholder="Last Name">
						</div> 
						<div class="form-group">
						  <label for="pemail">Email:</label><label id="em"></label>
						  <input type="email" class="form-control" id="pemail" placeholder="Email">
						</div> 
						<div class="form-group">
						  <label for="pphone">Phone No.:</label><label id="ph"></label>
						  <input type="text" class="form-control" id="pphone" placeholder="Phone No.">
						</div> 
						<div class="form-group">
						  <label for="pzcode">Zip Code:</label><label id="zc"></label>
						  <input type="text" class="form-control" id="pzcode" placeholder="Zip Code">
						</div> 
						<div class="form-group">
						  <label for="ppw">Password:</label><label id="pw"></label>
						  <input type="password" class="form-control" id="ppw" placeholder="Password">
						</div> 
						<div class="form-group">
						  <label for="cpw">Confirm Password:</label><label id="c"></label>
						  <input type="password" class="form-control" id="cpw" placeholder="Confirm Password">
						</div> 
						<div class="form-group">
						  <label for="pdate">Date:</label><label id="d"></label>
						  <input type="date" class="form-control" id="pdate">
						</div> 
						<div class="form-group">
						  <label for="pcity">Select city:</label><label id="cty"></label>
						  <select class="form-control" id="pcity">
						    <option value="">Select City</option>
						    <option value="Dhaka">Dhaka</option>
						    <option value="Chittagong">Chittagong</option>
						    <option value="Khulna">Khulna</option>
						    <option value="Barisal">Barisal</option>
						    <option value="Sylhet">Sylhet</option>
						    <option value="Rajshahi">Rajshahi</option>
						    <option value="Rangamati">Rangamati</option>
						  </select>
						</div> 
						<div class="container">
						<label>Select gender:</label>	
						  <form>
						    <label class="radio-inline">
						      <input type="radio" name="gender" value="male" checked>Male
						    </label>
						    <label class="radio-inline">
						      <input type="radio" name="gender" value="female">Female
						    </label>
						    <label class="radio-inline">
						      <input type="radio" name="gender" value="other">Other
						    </label><label id="gend"></label>
						  </form>
						</div>
						<div class="form-group">
						  <label for="padd">Adress:</label><label id="addr"></label>
						  <textarea class="form-control" rows="5" id="padd" placeholder="Address"></textarea>
						</div> 
						<input type="button" name="" value="Register" class="btn btn-success" onclick="register()">
						<!-- <input type="button" name="" value="Reset" class="btn btn-success" onclick="clear()"> -->

				</div>
		    </div>
		</div>		
	</div>
	
	<div  id="div2" class="container-fluid">
		<div class="container">
			<div class="panel panel-success">
		      <div class="panel-heading">Patient Login Details</div>
		      <div class="panel-body">
		      		<label>Patient Id:</label><label id="pid"></label>
					<br>
					<br>
					<label>Password:</label><label id="passw"></label>
					<input type="button" name="" value="Login" class="btn btn-success" onclick="login()">
		  	  </div>
		    </div>
		</div>

	</div>
	<div>
		<br>
			<br>
		<p align="center"><span color="white">
			


		Copyright@2021</span>


	</p>
	</div>
	<script type="text/javascript">
		document.getElementById('div2').style.display = "none";
		//<link rel="stylesheet" href="patientLoginStyle.css">

		
		function register(){

			var fname = document.getElementById('pfname').value;
		    var sname = document.getElementById('psname').value;
		    var email = document.getElementById('pemail').value; 
		    var phone = document.getElementById('pphone').value;
		    var pw = document.getElementById('ppw').value;
		    var cpw = document.getElementById('cpw').value;
		    var zip = document.getElementById('pzcode').value;
		    var city = document.getElementById('pcity').value;
		    var add = document.getElementById('padd').value;
		    var dob = document.getElementById('pdate').value;
		    var gen;

		    var ele = document.getElementsByName('gender'); 
              
            for(i = 0; i < ele.length; i++) { 
                if(ele[i].checked){
                	gen = ele[i].value; 
                }                 
            }

            if (fname==''||sname==''||email==''||phone==''||pw==''||zip==''||city==''||add==''||dob==''||gen==''|| !emailIsValid(email)||phone.length<11||pw.length<8||zip.length<4||pw!=cpw) {

            	if (fname=='') {
            		document.getElementById('fn').innerHTML = "<span style=\"color:red\"> *First name cannot be empty.</span>";
            	}
            	if (sname=='') {
            		document.getElementById('sn').innerHTML = "<span style=\"color:red\"> *Last name cannot be empty.</span>";
            	}
            	if (email==''||!emailIsValid(email)) {
            		document.getElementById('em').innerHTML = "<span style=\"color:red\"> *Email is emply/Format is invalid</span>";
            	}
            	if (phone==''||phone.length<11) {
            		document.getElementById('ph').innerHTML = "<span style=\"color:red\"> *Phone number cannot be empty/Phone number is 11 charecters.</span>";
            	}
            	if (zip==''||zip.length<4) {
            		document.getElementById('zc').innerHTML = "<span style=\"color:red\"> *Zip code cannot be empty/Zip code is 4 digits</span>";
            	}
            	if (city=='') {
            		document.getElementById('cty').innerHTML = "<span style=\"color:red\"> *City cannot be empty.</span>";
            	}
            	if (add=='') {
            		document.getElementById('addr').innerHTML = "<span style=\"color:red\"> *Address cannot be empty.</span>";
            	}
            	if (dob=='') {
            		document.getElementById('d').innerHTML = "<span style=\"color:red\"> *DOB cannot be empty.</span>";
            	}
            	if (gen=='') {
            		document.getElementById('gend').innerHTML = "<span style=\"color:red\"> *Gender cannot be empty.</span>";
            	}
            	if (pw==''||pw.length<8) {
            		document.getElementById('pw').innerHTML = "<span style=\"color:red\"> *Password cannot be empty/Password must be atleast 8 charecters.</span>";	
            	}
            	if (checkDate(dob)!=true) {
					document.getElementById('d').innerHTML = "<span style=\"color:red\"> * DOB not in range.</span>";
				}
				if (pw!=cpw) {
					document.getElementById('c').innerHTML = "<span style=\"color:red\"> * Passwords do not match!</span>";					
				}


            	document.getElementById('inf').innerHTML = "<div class=\"alert alert-warning\"><strong>Empty Entry!</strong> Input fields are empty/Incorrect.</div>";

            }else{

            	var xhttp = new XMLHttpRequest();
			 	xhttp.open('POST', '../../php/patientRegisterC.php', true);
				xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
				xhttp.send('reg='+'true'+'&fname='+fname+'&sname='+sname+'&email='+email+'&phone='+phone+'&pw='+pw+'&zip='+zip+'&city='+city+'&add='+add+'&dob='+dob+'&gen='+gen);

	         	xhttp.onreadystatechange = function(){
					if(this.readyState == 4 && this.status == 200){

						if (this.responseText!="Unexpected error. Try again later" || this.responseText!="error") {
							document.getElementById('div1').style.display = "none";
							document.getElementById('div2').style.display = "block";
							document.getElementById('pid').innerHTML = this.responseText;
							document.getElementById('passw').innerHTML = pw;
						}else{

						document.getElementById('res').innerHTML = this.responseText;

					}

											
					}
				}

            }




		}

		function login(){
			window.location.assign("patientLogin.php");
		}

		function emailIsValid (email) {
		  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
		}

		function clear(){
			location.reload(); 
		}

		function checkDate(field)
		  {
		    var allowBlank = true;
		    var minYear = 1902;
		    var maxYear = 2005;

		    var errorMsg = "";

		    // regular expression to match required date format
		    re = /^(\d{4})-(\d{1,2})-(\d{1,2})$/;

		    if(field != '') {
		      if(regs = field.match(re)) {
		        if(regs[3] < 1 || regs[3] > 31) {
		          errorMsg = "Invalid value for day: " + regs[3];
		        } else if(regs[2] < 1 || regs[2] > 12) {
		          errorMsg = "Invalid value for month: " + regs[2];
		        } else if(regs[1] < minYear || regs[1] > maxYear) {
		          errorMsg = "Invalid value for year: " + regs[1] + " - must be between " + minYear + " and " + maxYear;
		        }
		      } else {
		        errorMsg = "Invalid date format: " + field;
		      }
		    } else if(!allowBlank) {
		      errorMsg = "Empty date not allowed!";
		    }

		    if(errorMsg != "") {
		      console.log(errorMsg);
		      //field.focus();
		      return false;
		    }else{
		    	return true;
		    }

		    
		  }

	</script>
	

</body>
</html>