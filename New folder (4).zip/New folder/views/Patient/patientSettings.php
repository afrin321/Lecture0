<?php
    require_once('../../php/sessionC.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	   	<meta charset="utf-8">
	  	<meta name="viewport" content="width=device-width, initial-scale=1">
  		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>  
		<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
		<link rel="stylesheet" href="../../homestyle.css">
</head>
<body>


<div class="container-fluid">
		<ul class="up">
			<li class="left"><img src="../../logo.png" class="img-fluid" class="left"></li>
			<li class="up">
				<form action="../../php/loginC.php" method="post">
					<input type="submit" class="btn btn-primary logout" name="plog" value="Logout">
				</form>
			</li>			
		</ul>
	</div>
	<nav class="navbar menu">
  		<div class="container-fluid">    
			<ul class="menu nav navbar-nav">
				<li class="menu">
					<a href="patientHome.php" class="menu">Home  <span class="glyphicon glyphicon-bell"><span  class="badge badge-light" id="n5"></span></a>
				</li>
				<li class="menu">
					<a href="patientAppointment.php" class="menu">Appointments</a>
				</li>
				<li class="menu">
					<a href="patientQueue.php" class="menu">Queue Information</a>
				</li>
				<li class="menu">
					<a href="patientLogs.php" class="menu">Appointment Log</a>
				</li>
				<li class="menu">
					<a href="patientPayment.php" class="menu">Payment</a>
				</li>
				<li class="menu">
					<a href="patientSettings.php" class="menu">Settings</a>
				</li>
			</ul>
		</div>
	</nav>

		<div class="container" id="div1">
		  <h1 class="display-3">Change Password</h1>
		  <hr>
		  Enter Current Password to change password.
		  <br>
		  <br>
		  <div id="check"></div>
			<div class="form-group">
		    	<label for="pwd">Password:</label>
				<input type="password" class="form-control" id="pwd" placeholder="Password">
			</div>
			<button type="button" class="btn btn-primary" onclick="verify()">Change</button>
		</div>

		<div class="container" id="div2">
		  <h1 class="display-3">Change Password</h1>
		  <hr>
		  Enter New Password to change password.
		  <br>
		  <br>
		  	<div id="check2"></div>
			<div class="form-group">
		    	<label for="npwd">New Password:</label>
				<input type="password" class="form-control" id="npwd" placeholder="Password">
			</div>
			<div class="form-group">
		    	<label for="cpwd">Confirm Password:</label>
				<input type="password" class="form-control" id="cpwd" placeholder="Password">
			</div>
			<button type="button" class="btn btn-primary" onclick="changePw()">Change Password</button>
		</div>



		<script type="text/javascript">
			document.getElementById('div2').style.display = 'none';
			getNumber();

			function verify(){
				var pw = document.getElementById('pwd').value;

				if (pw=='') {
					document.getElementById('check').innerHTML = "<div class=\"alert alert-danger\"><strong>Danger!</strong> Input field Empty! </div>";
				}else{


				var xhttp = new XMLHttpRequest();
		 		xhttp.open('POST', '../../php/patientSettingsC.php', true);
				xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
				xhttp.send('ver='+'true'+'&pw='+pw);

				xhttp.onreadystatechange = function(){
					if(this.readyState == 4 && this.status == 200){

						//document.getElementById('div1').innerHTML = this.responseText;

						if (this.responseText.trim()=='success') {
							document.getElementById('div2').style.display = 'block';
							document.getElementById('div1').style.display = 'none';
						}else{
							document.getElementById('check').innerHTML = "<div class=\"alert alert-danger\"><strong>Danger!</strong> Passwords do not match! </div>";
						}
					}
				}
			}
			}

			function changePw(){

				var np = document.getElementById('npwd').value;
				var cp = document.getElementById('cpwd').value;

				if (np==''||cp=='') {

					document.getElementById('check2').innerHTML = "<div class=\"alert alert-danger\"><strong>Danger!</strong> Empty Input Field! </div>";

				}else if (np!=cp) {

					document.getElementById('check2').innerHTML = "<div class=\"alert alert-danger\"><strong>Danger!</strong> Passwords do not match! </div>";
				}else{

					var xhttp2 = new XMLHttpRequest();
			 		xhttp2.open('POST', '../../php/patientSettingsC.php', true);
					xhttp2.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
					xhttp2.send('changep='+'true'+'&pw='+np);

					xhttp2.onreadystatechange = function(){
					if(this.readyState == 4 && this.status == 200){
							if (this.responseText.trim()=='success') {
								document.getElementById('check2').innerHTML = "<div class=\"alert alert-success\"><strong>Success!</strong> Updated Successfully.</div>";
							}else{
								document.getElementById('check2').innerHTML = "<div class=\"alert alert-danger\"><strong>Danger!</strong> Some error occured </div>";
							}
						}
					}


				}



			}

				function getNumber(){

			//document.getElementById('n5').style.display='none';

			var xhttp22 = new XMLHttpRequest();
		 	xhttp22.open('POST', '../../php/patientHomeC.php', true);
			xhttp22.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp22.send('getn='+'true');

			xhttp22.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					var res = this.responseText;
					//document.getElementById('n5').innerHTML = res;
					if (res=='zero') {

						document.getElementById('n5').style.display='none';
					}else{
						document.getElementById('n5').innerHTML = res;
						document.getElementById('n5').style.display ='hidden';
					}


				}
			}
		}
			
		</script>






	


</body>
</html>