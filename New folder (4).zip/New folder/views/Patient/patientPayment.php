<?php

require_once('../../php/sessionC.php');
//echo $_COOKIE['pid'];

?>


<!DOCTYPE html>
<html>
<head>
	<title>Homepage</title>
	   	
	  	<meta charset="utf-8">
  		<meta name="viewport" content="width=device-width, initial-scale=1">
  		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  
		<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
		<link rel="stylesheet" href="../../homestyle.css">
	<!-- <link rel="stylesheet" href="homestylePayment.css"> -->
	
</head>
<body onload="startActions()">
	<div class="container-fluid">
		<ul class="up">
			<li class="left"><img src="../../logo.png" class="img-fluid" class="left"></li>
			<li class="up">
				<form action="../../php/loginC.php" method="post">
					<input type="submit" class="btn btn-primary logout" name="plog" value="Logout">
				</form>
			</li>			
		</ul>
	</div>
	
	<nav class="navbar menu">
  		<div class="container-fluid">    
			<ul class="menu nav navbar-nav">
				<li class="menu">
					<a href="patientHome.php" class="menu">Home  <span class="glyphicon glyphicon-bell"><span  class="badge badge-light" id="n5"></span></a>
				</li>
				<li class="menu">
					<a href="patientAppointment.php" class="menu">Appointments</a>
				</li>
				<li class="menu">
					<a href="patientQueue.php" class="menu">Queue Information</a>
				</li>
				<li class="menu">
					<a href="patientLogs.php" class="menu">Appointment Log</a>
				</li>
				<li class="menu">
					<a href="patientPayment.php" class="menu">Payment</a>
				</li>
				<li class="menu">
					<a href="patientSettings.php" class="menu">Settings</a>
				</li>
			</ul>
		</div>
	</nav>
	<p id="resofw"></p>
	<div class="container">
			<h1 class="display-5">Payments</h1>
			<hr>
			<br>
		<div id="res" class="container-fluid">
			<div>
				<legend><h3>Current Payment</h3></legend>

				<div>
					
				</div>
			</div>
		</div>
		<div id="res3" class="container-fluid"></div>
		<div class="container">
			<div class="panel panel-default">
  				<div class="panel-body">	
					<h2>Pending Payment</h2>
					<br>
					<p>Complete payment to book your spot.</p>
					<div id="res2"></div>
					<br>
				</div>
			</div>
		</div>
		<br><!-- 
		<div class="container-fluid">
			Current Balance: Tk.<label id="balance"></label>
		</div> -->
		
	</div>

	<script type="text/javascript">

		setInterval("startActions()", 5000);
		document.getElementById('res3').style.display = "none";
		getNumber();

		document.getElementById('res').style.display = "none";

		function startActions(){
			checkP();
			waitList();
			//getBalace();
			
		}

		function logout(){

			var xhttp200 = new XMLHttpRequest();
		 	xhttp200.open('POST', '../../php/loginC.php', true);
			xhttp200.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp200.send('plog='+'true');

			xhttp200.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					if (this.responseText=='yes') {
						location.replace("./../../index.php");
					}

				}
			}


		}


		
		function checkP(){

			var xhttp = new XMLHttpRequest();
		 	xhttp.open('POST', '../../php/paymentC.php', true);
			xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp.send('check_p='+'true');

			xhttp.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					if (this.responseText=="false"){

						document.getElementById('res').innerHTML = "";
						document.getElementById('res').style.display = "block";

					}else if(this.responseText=="pay"){

						document.getElementById('res').innerHTML = "<input type=\"button\" value=\"Pay\" onclick=\"pay()\" class=\"btn btn-primary\">"+"  "+"<input type=\"button\" value=\"Cancel\" onclick=\"cancelPay()\" class=\"btn btn-primary\">";
						document.getElementById('res').style.display = "block";

					}else if(this.responseText=="success"){
						document.getElementById('res').innerHTML = "Appointment made successfully.";
						document.getElementById('res').style.display = "block";
					}else{

						document.getElementById('res').innerHTML = this.responseText;
						document.getElementById('res').style.display = "block";
					}

					
				}
			}
		}

		function cancelApp(){

			var xhttp2 = new XMLHttpRequest();
		 	xhttp2.open('POST', '../../php/paymentC.php', true);
			xhttp2.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp2.send('cancelp='+'true');

			xhttp2.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					if (this.responseText) {

						
						document.getElementById('res').innerHTML = "";
						document.getElementById('res').style.display = "none";
						
									
				}
			}
		}
	}

	function confirm(){

		document.getElementById('res').innerHTML = "Processing...";
		document.getElementById('res').style.display = "block";

		var xhttp3 = new XMLHttpRequest();
		 	xhttp3.open('POST', '../../php/paymentC.php', true);
			xhttp3.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp3.send('conf='+'true');

			xhttp3.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){



										
						//document.getElementById('res').innerHTML = this.responseText;
						document.getElementById('res').style.display = "block";
						
						
									
				}
		}


	}

	function pay(){

		document.getElementById('res').innerHTML = "Processing...";
		document.getElementById('res').style.display = "block";



		var xhttp4 = new XMLHttpRequest();
		 	xhttp4.open('POST', '../../php/paymentC.php', true);
			xhttp4.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp4.send('pay='+'true');

			xhttp4.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

										
						//document.getElementById('res').innerHTML = this.responseText;
						if (this.responseText=="success") {

							document.getElementById('res').innerHTML = "Successfully added";
							document.getElementById('res').style.display = "block";
						}else{
							document.getElementById('res').innerHTML = "In progress..";
							document.getElementById('res').style.display = "block";

						}
						//document.getElementById('res').style.display = "block";
						
						
									
				}
		}

	}

	function cancelPay(){

		document.getElementById('res').innerHTML = "Processing...";
		document.getElementById('res').style.display = "block";



		    var xhttp5 = new XMLHttpRequest();
		 	xhttp5.open('POST', '../../php/paymentC.php', true);
			xhttp5.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp5.send('cancelpay='+'true');

			xhttp5.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){
									
						//document.getElementById('res').innerHTML = this.responseText;
						if (this.responseText=="success") {
							document.getElementById('res').innerHTML = "Successfully cancelled.";
							document.getElementById('res').style.display = "block";
						}
					
							//document.getElementById('res').style.display = "block";
							//document.getElementById('res').style.display = "block";				
						
									
				}
		}


	}

	function waitList(){

		//document.getElementById('res2').innerHTML = "suppose";
		//document.getElementById('res2').style.display = "block";

		var xhttp6 = new XMLHttpRequest();
		 	xhttp6.open('POST', '../../php/paymentC.php', true);
			xhttp6.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp6.send('waitlist='+'true');

			xhttp6.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){
									
						//document.getElementById('res').innerHTML = this.responseText;
						if (this.responseText!="error") {
						
							document.getElementById('res2').innerHTML = this.responseText;
							document.getElementById('res2').style.display = "block";

						}else{

							document.getElementById('res2').innerHTML = "Empty";
							document.getElementById('res2').style.display = "block";

						}
								
							//document.getElementById('res').style.display = "block";
							//document.getElementById('res').style.display = "block";				
										
				}
		}

	}

	function payLate(wid, apid){

		//document.getElementById('res').innerHTML = "Processing...";
		//document.getElementById('res').style.display = "block";

		//var appId = document.getElementById('getid').innerHTML; 
		//var wd = document.getElementById('getid').value; 

		//document.getElementById('getid').innerHTML = appId+"  "+wid;
		//document.getElementById('resofw').style.display = "block";

		



		var xhttp7 = new XMLHttpRequest();
		 	xhttp7.open('POST', '../../php/paymentC.php', true);
			xhttp7.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp7.send('ap_w='+'true'+'&apid='+apid+'&wd='+wid);

			xhttp7.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

										
						//document.getElementById('res').innerHTML = this.responseText;
						if (this.responseText=="success") {

							document.getElementById('res').innerHTML = "Successfully added";
							document.getElementById('res').style.display = "block";
						}else{
							document.getElementById('res').innerHTML = "In progress..";
							document.getElementById('res').style.display = "block";

						}
						//document.getElementById('res').style.display = "block";
						
						
									
				}
		}



	}

	function cancelWait(wd){

		document.getElementById('res').innerHTML = "Cancelling...";

			var xhttp8 = new XMLHttpRequest();
		 	xhttp8.open('POST', '../../php/paymentC.php', true);
			xhttp8.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp8.send('wcancel='+wd);

			xhttp8.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					if (this.responseText=="yes") {

										
						document.getElementById('res').innerHTML = "Cancelled Successfully.";

					}
						
						//document.getElementById('res').style.display = "block";
						
						
									
				}
		}

	}

	// function getBalace(){

	// 	var xhttp9 = new XMLHttpRequest();
	// 	 	xhttp9.open('POST', '../../php/paymentC.php', true);
	// 		xhttp9.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
	// 		xhttp9.send('accb='+'true');

	// 		xhttp9.onreadystatechange = function(){
	// 			if(this.readyState == 4 && this.status == 200){

	// 				document.getElementById('balance').innerHTML = this.responseText;

	// 			}
	// 		}


	// }

	function getNumber(){

			//document.getElementById('n5').style.display='none';

			var xhttp22 = new XMLHttpRequest();
		 	xhttp22.open('POST', '../../php/patientHomeC.php', true);
			xhttp22.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp22.send('getn='+'true');

			xhttp22.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					var res = this.responseText;
					//document.getElementById('n5').innerHTML = res;
					if (res=='zero') {

						document.getElementById('n5').style.display='none';
					}else{
						document.getElementById('n5').innerHTML = res;
						document.getElementById('n5').style.display ='block';
					}


				}
			}
		}

	</script>

	

	


</body>
</html>