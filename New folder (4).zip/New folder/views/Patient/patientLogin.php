<!DOCTYPE html>
<html>
<head>
	<title>Patient Portal</title>
	   	<meta charset="utf-8">
	  	<meta name="viewport" content="width=device-width, initial-scale=1">
	  	<meta charset="utf-8">
  		<meta name="viewport" content="width=device-width, initial-scale=1">
  		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  
		<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
		<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
		<link rel="stylesheet" href="patientLoginStyle.css">
</head>
<body>
	<div class="container">
		<div class="container" id="inf"></div>
		<div class="container">
			<div class="panel panel-info">
		      <div class="panel-heading"><h2 class="text-center">Patient Portal</h2></div>
		      	<div id="c1"></div>
			      <div class="panel-body">
			      	<div class="form-group">
						<label for="pid">Patient Id:</label><label id="p1"></label>
						<input type="text" placeholder="Enter Patient Id" class="form-control" id="pid" onclick="clearAll()">
					</div>
					<div class="form-group">
						<label for="ppw">Password:</label><label id="p2"></label>
						<input type="password" placeholder="Enter Password" class="form-control" id="ppw" onclick="clearAll()">
					</div> 
					
					<input type="button" class="btn btn-primary" value="Login" onclick="login()"><label id="p3"></label>
					
					Do not have an account? <a href="patientRegister.php">Click here to register.</a>
			      	
			      </div>
		    </div>
		</div>
<!-- 		<fieldset>
		<form method="post" action="../../php/loginC.php">
			<label>Patient Id</label><br>
			<input type="text" name="" placeholder="Enter Patient Id" id="pid" onclick="clearAll()"> <label id="p1"></label><br>
			<br>
			<label>Password</label><br>
			<input type="password" name="" placeholder="Enter Password" id="ppw" onclick="clearAll()"> <label id="p2"></label>   <a href="#">Forgotten password?</a><br>
			<br>
			<input type="button" name="" value="Login" onclick="login()">  <input type="checkbox" name=""> Remember me. <label id="p3"></label> <br> 
			<br>
			
			<br>
			Do not have an account? <a href="patientRegister.php">Register here.</a>
		</form>
	</fieldset> -->
	</div>

	<script type="text/javascript">

		var oldURL = document.referrer;

		if (oldURL.trim()=="http://localhost/New%20folder/views/appointment.php") {

			document.getElementById('inf').innerHTML = "<div class=\"alert alert-warning\"><strong>Login!</strong> Login first to confirm appointment.</div>";

		}

		function clearAll(){
			document.getElementById('p1').innerHTML = "";
			document.getElementById('p2').innerHTML = "";
		}

		function login(){

			var pid = document.getElementById('pid').value;
			var ppw = document.getElementById('ppw').value;

			if ((pid=='')||(ppw=='')) {
				document.getElementById('c1').innerHTML = "<div class=\"alert alert-danger\"><strong>Danger!</strong> Empty/Incorrect Fields Present</div>";
				if (pid=='') {

					document.getElementById('p1').innerHTML = "<span style=\"color:red\">  *Patient Id is missing!</span>";

				}
				if (ppw=='') {

					document.getElementById('p2').innerHTML = "<span style=\"color:red\">   *Password is missing!</span>";

				}
			}else{

				var xhttp = new XMLHttpRequest();
		 	    xhttp.open('POST', '../../php/loginC.php', true);
			    xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			    xhttp.send('plogin='+'true'+'&pid='+pid+'&ppw='+ppw);

         	xhttp.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					if (this.responseText=='true') {

						window.location.assign("patientHome.php");
					}else{

						document.getElementById('p3').innerHTML = '<span style=\"color:red\">   Invalid Patient Id or password. </span><br>';

					}



															
				}
			}
			}




		}
		
	</script>
	

</body>
</html>