<?php

    require_once('../../php/sessionC.php');

?>


<!DOCTYPE html>
<html>
<head>
	<title>Homepage</title>
	   	<meta charset="utf-8">
	  	<meta name="viewport" content="width=device-width, initial-scale=1">
	  	<meta charset="utf-8">
  		<meta name="viewport" content="width=device-width, initial-scale=1">
  		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  
		<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
		<link rel="stylesheet" href="../../homestyle.css">
</head>
<body onload="getNumber()">
	<div class="container-fluid">
		<ul class="up">
			<li class="left"><img src="../../logo.png" class="img-fluid" class="left"></li>
			<li class="up">
				<form action="../../php/loginC.php" method="post">
					<input type="submit" class="btn btn-primary logout" name="plog" value="Logout">
				</form>
			</li>			
		</ul>
	</div>

	<nav class="navbar menu">
  		<div class="container-fluid">    
			<ul class="menu nav navbar-nav">
				<li class="menu">
					<a href="patientHome.php" class="menu">Home  <span class="glyphicon glyphicon-bell"><span  class="badge badge-light" id="n5"></span></span></a>
				</li>
				<li class="menu">
					<a href="patientAppointment.php" class="menu">Appointments</a>
				</li>
				<li class="menu">
					<a href="patientQueue.php" class="menu">Queue Information</a>
				</li>
				<li class="menu">
					<a href="patientLogs.php" class="menu">Appointment Log</a>
				</li>
				<li class="menu">
					<a href="patientPayment.php" class="menu">Payment</a>
				</li>
				<li class="menu">
					<a href="patientSettings.php" class="menu">Settings</a>
				</li>
			</ul>
		</div>
	</nav>

	<div class="container">
			<h1 class="display-5">Home</h1>
			<hr>
			<br>
			<div class="Notify container" id="n1">
				<label class="open1">
					<button onclick="viewNotification()" id="bt1" class="btn btn-info glyphicon glyphicon-bell"> Notifications<span class="label label-info" id="n6"></button>
				</label>

				<div id="n2" class="container">
					
				</div>
			
			</div>
			<div class="container">
				
			</div>
	</div>

	<div>
		<br>
		<br>
<!-- 		<div class="Notify" id="n1">

			<span class="notify3" id="n5"></span>
			<label>Notifications</label><label class="open1"><input type="button" name="" value="Open" onclick="viewNotification()"></label>

			<div id="n2">
				
			</div>
			
		</div> -->
		<div id="sound_n">
			
		</div>

		<!-- <label id=\"topay\"></label> -->


		
	</div>

	<script type="text/javascript">

		//document.getElementById('n2').style.display = "none";
		//document.getElementById('n5').style.display='none';

		

		function viewNotification() {
			//document.getElementById('n2').style.display='none';
			if (document.getElementById('n2').style.display=='none') {
				document.getElementById('n2').style.display='block';
				document.getElementById('bt1').value = "Close";
			}else{
				document.getElementById('n2').style.display='none';
				document.getElementById('bt1').value = "Open";
			}
			
			var xhttp = new XMLHttpRequest();
		 	xhttp.open('POST', '../../php/patientHomeC.php', true);
			xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp.send('viewn='+'true');

			xhttp.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					//document.getElementById('n5').style.display = 'none';

					document.getElementById('n2').innerHTML = this.responseText;

					if (this.responseText=="<br><br>error") {

						//document.getElementById('n2').style.display = "block"; //"hidden";

						document.getElementById('n2').innerHTML = "<br>No notifications at the moment.";

					}else{

						//document.getElementById('n2').style.display = "block";

						document.getElementById('n2').innerHTML = this.responseText;

					}

				}
			}
		}

		function getNumber(){

			//document.getElementById('n5').style.display='none';

			var xhttp2 = new XMLHttpRequest();
		 	xhttp2.open('POST', '../../php/patientHomeC.php', true);
			xhttp2.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp2.send('getn='+'true');

			xhttp2.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					var res = this.responseText;
					//document.getElementById('n5').innerHTML = res;
					if (res=='zero') {

						document.getElementById('n5').style.display='none';
						document.getElementById('n6').style.display='none';
					}else{
						document.getElementById('n5').innerHTML = res;
						document.getElementById('n5').style.display ='hidden';
						document.getElementById('n6').innerHTML = res;
						document.getElementById('n6').style.display ='hidden';
					}


				}
			}
		}

		// function logout(){

		// 	var xhttp200 = new XMLHttpRequest();
		//  	xhttp200.open('POST', '../../php/loginC.php', true);
		// 	xhttp200.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
		// 	xhttp200.send('plog='+'true');

		// 	xhttp200.onreadystatechange = function(){
		// 		if(this.readyState == 4 && this.status == 200){

		// 			if (this.responseText=='yes') {
		// 				location.replace("./../../index.php");
		// 			}

		// 		}
		// 	}


		// }

		
		
	</script>

	


</body>
</html>