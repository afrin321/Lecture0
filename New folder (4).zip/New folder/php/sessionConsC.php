<?php

	session_start();
	if(!isset($_COOKIE['cons_id'])){
		header("location:./../../index.php");
	}

?>