<?php

    session_start();

	require_once('../service/userService.php');

	if (isset($_POST['all'])) {
		$m = getAllCons();

		if ($m) {
			# code...
		
		$data = "<h3 class=\"display-5\">All Consultant Accounts</h3>
				<hr>
				<br>
		<div  class=\"table-responsive\"><table class=\"table\">
				<tr>
				    <th>Image</th>
					<th>Id</th>
					<th>Name</th>
					<th>Department</th>
					<th>Phone</th>
					<th>Email</th>
					<th>Address</th>
					<th>DOB</th>
					<th>Qualification</th>
					<th>Experience</th>
					<th>Options</th>
				</tr>";

	while ($row = mysqli_fetch_assoc($m)) {
		$data .= "<tr>
		            <td><img src=\"{$row['consPhoto']}\" class=\"img-fluid img-thumbnail\" width=\"120px\" height=\"120px\"></td>
					<td>{$row['ConsID']}</td>
					<td>{$row['consName']}</td>
					<td>{$row['consDept']}</td>
					<td>{$row['consPhoneNo']}</td>
					<td>{$row['consEmail']}</td>
					<td>{$row['consAddrs']}</td>
					<td>{$row['consDOB']}</td>
					<td>{$row['consQual']}</td>
					<td>{$row['consExp']}</td>
					<td>";

					if ($row['consStat']=='Deactive') {
					$data .=	"Account Deactivated";
					}else{
						$data .= "<button type=\"button\" class=\"btn btn-primary\" onclick=\"openSlot(".$row['ConsID'].")\">Open Slots</button><button type=\"button\" class=\"btn btn-danger\" onclick=\"deleteCons(".$row['ConsID'].")\">Deactivate</button></td>";
					}
					
				$data .= "</tr>";
				//<button type=\"button\" class=\"btn btn-danger\" onclick=\"deleteCons(".$row['ConsID'].")\">Delete</button>

	}

	$data .= "</table></div>";
	

	
	   echo $data;
	}else{
		echo "error 8";
	}

	}

	if (isset($_POST['initialpass'])) {

		if (empty($_POST['id1'])||empty($_POST['initialpass'])) {
			if (empty($_POST['id1'])) {
				echo "id empty";
			}elseif (empty($_POST['initialpass'])) {
				echo "pass empty";
			}elseif ((empty($_POST['id1'])&&empty($_POST['initialpass']))) {
				echo "both";
			}
			
		}else{
			$data = [

				'id'=>$_POST['id1'],
				'pw'=>$_POST['initialpass']
			];

			$status = addPasswordConsultant($data);

			if ($status) {
				echo "success";
			}else{
				echo "error7";
			}
		}
		
	}

	if (isset($_POST['cname'])) {

		$zz = searchCons($_POST['cname']);

		if ($zz) {
			$data = "<div class=\"table-responsive\"><table class=\"table\">
				<tr>
				    <th>Image</th>
					<th>Id</th>
					<th>Name</th>
					<th>Department</th>
					<th>Phone</th>
					<th>Email</th>
					<th>Address</th>
					<th>DOB</th>
					<th>Qualification</th>
					<th>Experience</th>
					<th>Option</td>
				</tr>";

	while ($row = mysqli_fetch_assoc($zz)) {
		$data .= "<tr>
		            <td><img src=\"{$row['consPhoto']}\" class=\"img-fluid img-thumbnail\" width=\"120px\" height=\"120px\"></td>
					<td>{$row['ConsID']}</td>
					<td>{$row['consName']}</td>
					<td>{$row['consDept']}</td>
					<td>{$row['consPhoneNo']}</td>
					<td>{$row['consEmail']}</td>
					<td>{$row['consAddrs']}</td>
					<td>{$row['consDOB']}</td>
					<td>{$row['consQual']}</td>
					<td>{$row['consExp']}</td>
					<td><button type=\"button\" class=\"btn btn-primary\" onclick=\"openSlotTwo(".$row['ConsID'].")\">Open Slots</button><button type=\"button\" class=\"btn btn-danger\" onclick=\"deleteConsTwo(".$row['ConsID'].")\">Deactivate</button><td>
				</tr>";
	}
	$data .= "</table></div>";

	echo $data;
		}else{
			echo "error 5";
		}
		

		

	}

	if (isset($_POST['pupload'])) {

		//$targetdir = '../db/uploads/';
		//move_uploaded_file($_FILES["cphoto"]["tmp_name"], $targetdir);
		///$targetfilename = $targetdir.basename($_FILES['cphoto']['tmp_name']);
		//$photo = $targetfilename;

		$target_dir = "../db/uploads/";
        $target_file = $target_dir . basename($_FILES["cphoto"]["name"]);

		move_uploaded_file($_FILES["cphoto"]["tmp_name"], $target_file);

		$z = uploadConsPhoto($target_file);

		if($z){
			header('location: ../views/adminConsultants.php?success=true');
		}else{
			echo "error4";
		}
	}

	if(isset($_POST['cid'])){
		$y = getCurrentID();
		if($y){
			echo $y['ConsID'];
		}else{
			echo 'error3';
		}
	}

	if(isset($_POST['name'])){

		//echo "hii";




		//$targetdir = '../db/uploads/';


		$name = $_POST['name'];
		$dept = $_POST['dept'];
		$phone = $_POST['phone'];
		$email = $_POST['email'];
		$address = $_POST['address'];
		$dob = $_POST['dob'];
		$qualification = $_POST['qualification'];
		$exp = $_POST['exp'];
		$avail = $_POST['dayavail'];
		//$photo = $_FILES['photo'];

		if(empty($name)||empty($dept)||empty($phone)||empty($email)||empty($address)||empty($dob)||empty($qualification)||empty($exp)||empty($avail)){
			echo "empty";
		}else{

			//echo "done";

			$data =[
				'name'=>$name,
				'dept'=>$dept,
				'phone'=>$phone,
				'email'=>$email,
				'address'=>$address,
				'dob'=>$dob,
				'qualification'=>$qualification,
				'exp'=>$exp,
				'avail'=>$avail
			];

			//$x = getDeptId($dept);
			//echo $x;

			$status = createConsultantAccount($data);

			if ($status) {
				echo "success";
				//$x = getDeptId($dept);
				//echo $x;
			}else{
				echo "error2";
			}

			//move_uploaded_file($_FILES["photo"]["tmp_name"], $targetdir);
		    //$targetfilename = $targetdir.basename($_FILES['photo']['tmp_name']);
		    //$photo = $targetfilename;

		}





	}

	if(isset($_POST['full_list'])){

		//echo "hii11";

		$x = getAllConsForSlot();

		echo "
		             
		                 <option value=\"\">Select Consultant</option>";

		for ($i=0; $i <count($x) ; $i++) { 
			echo "<option";
			echo " value=\"";
			echo $x[$i]['consName'];
			echo "\" >";
			echo $x[$i]['consName'];
			echo "</option>";
		}

		
		
	}

	if(isset($_POST['full_list_d'])){

		//echo "hii11";

		$x = getAllDept();
		echo "Department: ";
		echo "<option value=\"\">Select Department</option>";

		for ($i=0; $i <count($x) ; $i++) { 
			echo "<option";
			echo " value=\"";
			echo $x[$i]['deptName'];
			echo "\" >";
			echo $x[$i]['deptName'];
			echo "</option>";
		}

		echo "</select>";
	}

	if (isset($_POST['delcon'])) {

		//echo "hii";

		$slot_d = getInfoForSlotApp($_POST['delcon']);
		//echo implode(" ", $slot_d[1]);
		
		if($slot_d){

			for ($i=0; $i < count($slot_d); $i++) { 
		
			$e = $slot_d[$i]['slot_id'];
			//echo "e: ".$slot_d[$i]['slot_id'];
			if ($e) {
				$d = listcancelslot($e);

				if ($d) {
		
				if (count($d)>0) {
					for ($i=0; $i <count($d) ; $i++) {
		
						$qid = $d[$i]['queueId'];
						$b = listForCancel($qid);
		
						if ($b && (count($b)>0)) {
							
						for ($i=0; $i < count($b); $i++) { 
							$pid = $b[$i]['pid'];
							$sid = $d[$i]['queueSlotId'];
		
							$t = time();
							//echo(date("d-m-Y",$t));
				
							$tempDate = date("d-m-Y",$t);
							$Date1 = date('Y-m-d',strtotime($tempDate));
				
				
							$d2 = [
								'p'=>$pid,
								's'=>$sid
				
							];
		
							$title = "Cancelled Appointment";
				
							$m = "Dear valued Client, your Appointment on ".$d[$i]['queueDate']." has been cancelled. Your payment has been refunded.	
												- Hospital Management";
		
		
							$d3 = [
									'p'=>$pid,
									'm'=>$m,
									't'=>$Date1,
									'title'=>$title
							];
		
							echo "hiiii";
				
				
							$w = updateAccPay($d2);
							$v = notificationOne($d3);
							$u = updateAppQueueOnCancel($sid);
							$y2 = cancelforSlot($sid);
							$y3 = deleteSlot($sid);
							// $y4 = delCon($_POST['delcon']);
		
		
							if ($w && $v && $u && $y2 && $y3) {
								
								$v = 'yes';
							}

							// else{
							// 	echo $w." ".$v." ".$u." ".$y2." ".$y3." ".$y4;
							// }
		
		
						}
					}
		
		
		
		
					}
				}
				//here

			}
				}
					
				}}

				//here
				if (isset($v)) {
					if ($v=='yes') {
						$y4 = delCon($_POST['delcon']);

						if ($y4) {
							echo 'true';
						}else{
							echo 'false';
						}
					}
				}else{

					$y4 = delCon($_POST['delcon']);

						if ($y4) {
							echo 'true';
						}else{
							echo 'false';
						}

				}
		


	}

	if (isset($_POST['slot_in'])) {

		//$slot_list = getInfoForSlotApp($_POST['slot_in']);
		$slot_list = getInfoForSlotAppTwo($_POST['slot_in']);

		if ($slot_list) {

			echo "<div class=\"panel panel-default\"><div class=\"panel-body\">";

			$x2 = getInfoForSlot($_POST['slot_in']);

			echo "<h3><label>Dr. ".ucfirst($x2['consName'])."</label></h3><br>";

			
			echo "<div class=\"panel panel-default\"><div class=\"panel-body\"><div class=\"table-responsive\">
  				<table class=\"table\">
  				<tr><th>Id</th><th>Day</th><th>Start Time</th><th>End Time</th><th>Max Allowed</th><th>Options</th></tr>";

  				for ($i=0; $i < count($slot_list); $i++) { 
  					echo "<tr>";
  					echo "<td>".ucfirst($slot_list[$i]['slot_id'])."</td>";
  					echo "<td>".ucfirst($slot_list[$i]['slot_day'])."</td>";
  					echo "<td>".date("g:i a", strtotime($slot_list[$i]['slot_start_time']))."</td>";
  					echo "<td>".date("g:i a", strtotime($slot_list[$i]['slot_end_time']))."</td>";
  					echo "<td>".$slot_list[$i]['slot_maxAllowed']."</td>";
  					echo "<td><button type=\"button\" class=\"btn btn-danger\" onclick=\"deactivate(".$slot_list[$i]['slot_id'].")\">Deactivate</button></td>";
  					echo "</tr>";
  				} 				
    
  			echo "</table></div></div></div></div></div>";
		}else{
			echo "Slots not added for this consultant yet.";
		}
		

	}

	if (isset($_POST['deac'])) {
		
		$b = listcancelslotTwo($_POST['deac']);
		if ($b && (count($b)>0)) {

			for ($i=0; $i <count($b) ; $i++) { 

				if ($b[$i]['queueCurQuantity']>0) {
					
					$qid = $b[$i]['queueId'];
					$c = listForCancel($qid);

						for ($i=0; $i <count($c) ; $i++) { 
							$pid = $c[$i]['pid'];
							$t = time();
							$tempDate = date("d-m-Y",$t);
							$Date1 = date('Y-m-d',strtotime($tempDate));
							$d2 = [
								'p'=>$pid,
								's'=>$_POST['deac']	
							];

							$title = "Cancelled Appointment";
				
							$m = "Dear valued Client, your Appointment on ".$b[$i]['queueDate']." has been cancelled. Your payment has been refunded.	
												- Hospital Management";


							$d3 = [
									'p'=>$pid,
									'm'=>$m,
									't'=>$Date1,
									'title'=>$title
							];
				
				
							$w = updateAccPay($d2);
							$v = notificationOne($d3);
							$u = updateAppQueueOnCancel($qid);
							$y2 = cancelforSlot($_POST['deac']);
							$y3 = deleteSlot($_POST['deac']);
							$y4 = deleteAttSlot($_POST['deac']);

							if ($w && $v && $u && $y2 && $y3  && $y4) {
								echo "success";
							}else{
								echo "error1";
							}
						}
				}else{
					$y2 = cancelforSlot($_POST['deac']);
					$y3 = deleteSlot($_POST['deac']);
					$y4 = deleteAttSlot($_POST['deac']);

					if ($y2 && $y3 && $y4) {
						echo "success";
					}else{
						echo "error4";
					}
				}
			}
			
		}else{
			$y4 = deleteAttSlot($_POST['deac']);
			$y3 = deleteSlot($_POST['deac']);
			if ($y3 && $y4) {
				echo "success";
			}else{
				echo "error2";
			}

		}
	}

/* 
$name = $_POST['name'];
	
	$con = mysqli_connect('localhost', 'root', '', 'webtech');
	$sql = "select * from users where username like '%{$name}%'";

	$result = mysqli_query($con, $sql);

	$data = "<table border=1>
				<tr>
					<td>ID</td>
					<td>username</td>
					<td>email</td>
				</tr>";

	while ($row = mysqli_fetch_assoc($result)) {
		$data .= "<tr>
					<td>{$row['id']}</td>
					<td>{$row['username']}</td>
					<td>{$row['email']}</td>
				</tr>";
	}
	$data .= "</table>";
  */


?>