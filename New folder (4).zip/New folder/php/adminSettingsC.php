<?php
	session_start();

	require_once('../service/userService.php');

	if (isset($_POST['ver'])) {
		
		$data = [
			'id'=>$_COOKIE['uid'],
			'pw'=>$_POST['pw']
		];
		$x = checkAdmin($data);
		if ($x) {
			echo "success";
		}else{
			echo "error";
		}
	}

	if (isset($_POST['changep'])) {
		$data = [
			'id'=>$_COOKIE['uid'],
			'pw'=>$_POST['pw']
		];
		$y = changePwAdmin($data);
		if ($y) {
			echo "success";
		}else{
			echo "error";
		}
	}

?>




