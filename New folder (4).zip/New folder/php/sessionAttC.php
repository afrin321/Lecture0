<?php

	session_start();
	if(!isset($_COOKIE['au_id'])){
		header("location:./../../index.php");
	}

?>