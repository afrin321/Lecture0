<?php
	session_start();

	require_once('../service/userService.php');

	if (isset($_POST['ver'])) {
		
		$data = [
			'id'=>$_COOKIE['cons_id'],
			'pw'=>$_POST['pw']
		];
		$x = checkCons($data);
		if ($x) {
			echo "success";
		}else{
			echo "error";
		}
	}

	if (isset($_POST['changep'])) {
		$data = [
			'id'=>$_COOKIE['cons_id'],
			'pw'=>$_POST['pw']
		];
		$y = changePwCons($data);
		if ($y) {
			echo "success";
		}else{
			echo "error";
		}
	}

?>




