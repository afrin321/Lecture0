<?php
	session_start();

	require_once('../service/userService.php');

	if(isset($_POST['full_list'])){

		//echo "hii11";

		$x = getAllDept();

		echo "<div class=\"table-responsive\">";
		echo "<table class=\"table\">";
		echo "<tr>";
		echo "<th>ID</th><th>Name</th><th>Total Consultants</th><th>Status</th>";
		echo "</tr>";
		for ($i=0; $i <count($x) ; $i++) {
			$y = getAllConsByDept($x[$i]['deptName']); 
			echo "<tr><td>".$x[$i]['deptID']."</td><td>".$x[$i]['deptName']."</td><td>".count($y)."</td><td>";
			if (count($y)>0) {
				echo "Active";
			}else{
				echo "Inactive";
			}
			// echo "</td>

			// "<td><button type=\"button\" class=\"btn btn-primary\" onclick=\"editdept(".$x[$i]['deptID'].")\">Edit</button> | ";

			// if (count($y)>0) {
			// 	echo "Cannot be deleted";
			// }else{
			// 	echo "<button type=\"button\" class=\"btn btn-primary\" onclick=\"deldept(".$x[$i]['deptID'].")\">Delete</button>";
			// }

			echo "</td></tr>";
		}
		echo "</table>";
		echo "</div>";

		// echo "<select id=\"dep\">
		//              <ul>
		//                  <option value=\"\">Select Department</option>";

		// for ($i=0; $i <count($x) ; $i++) { 
		// 	echo "<option";
		// 	echo " value=\"";
		// 	echo $x[$i]['deptName'];
		// 	echo "\" >";
		// 	echo $x[$i]['deptName'];
		// 	echo "</option>";
		// }

		// echo "</select>";
		
	}

	if (isset($_POST['searchL'])) {
		
		$r = getAllDept();

		if ($r) {
			echo "<option value=\"\">Select Department</option>";

			for ($i=0; $i <count($r) ; $i++) { 
				echo "<option";
				echo " value=\"".$r[$i]['deptName']."\">";
				echo $r[$i]['deptName'];
				echo "</option>";
			}
		}else{
			echo "<option>Select Department</option>";
		}


	}

	if (isset($_POST['conL'])) {

		$y = getAllConsByDept($_POST['dept']); 

		$data = $_POST['dept'];

		echo "<h3>".$_POST['dept']."</h3><hr><br>";

		// echo "<div class=\"panel panel-default\">
  // <div class=\"panel-body\"><div class=\"container-fluid\">

		// 		<div class=\"form-group\">
  // 					<label for=\"cn\">Change Name:</label>
  // 					<input type=\"text\" class=\"form-control\" id=\"cn\" placeholder=\"Department Name\">
		// 		</div>
		// 		<button type=\"button\" class=\"btn btn-primary\">Change Name</button>
		// 		<br><br>
		// 		<div class=\"form-group\">";

				// if (count($y)>0) {
				// 	echo "<label>Delete Status:</label><br>Departments with assigned consultant accounts cannot be deleted unless consultant accounts are deleted.";
				// }else{

				// 	echo "<label>Delete Status:</label><br><button type=\"button\" class=\"btn btn-primary\">Delete</button>";

				// }

// 		echo		"
// 				</div>




// 			  </div></div>
// </div>";

		
		echo "<div class=\"panel panel-default\">
  <div class=\"panel-body\">";
		$z = getAllConsByDept($data);

		if ($z) {
			echo "<div class=\"table-responsive\">";
			echo "<table class=\"table\">";
			echo "<tr><th>Image</th><th>ID</th><th>Name</th><th>Phone</th><th>Email</th><th>Qualification</th><th>Experience</th></tr>";

			for ($i=0; $i < count($z) ; $i++) { 
				echo "<tr>";
				echo "<td><img class=\"img-fluid img-thumbnail\" src=\"".$z[$i]['consPhoto']."\" width=\"120px\" height=\"120px\"></td>";
				echo "<td>".$z[$i]['ConsID']."</td>";
				echo "<td>".$z[$i]['consName']."</td>";
				echo "<td>".$z[$i]['consPhoneNo']."</td>";
				echo "<td>".$z[$i]['consEmail']."</td>";
				echo "<td>".$z[$i]['consQual']."</td>";
				echo "<td>".$z[$i]['consExp']."</td>";
				echo "</tr>";
			}

			echo "</table>";
			echo "</div>";
		}else{
			echo "No consultant added to this department yet.";
		}

		echo "</div></div>";
	}

	if (isset($_POST['new'])) {
		$n = $_POST['dname'];

		if (empty($n)) {
			echo "false";
		}else{
		
				$q = checkDeptExists($n);
		
				if ($q) {
					$p = insertDept($n);
		
					if ($p) {
						echo "true";
					}else{
						echo "false";
					}		
		
				}else{
					echo "common";
				}
		}
	}

	if (isset($_POST['checkd'])) {
		$dep = $_POST['checkd'];
		
		$cd = getAllConsByDept($dep);

		if (count($cd)>0) {
			echo "false";
		}else{
			echo "true";
		}
	}
?>




