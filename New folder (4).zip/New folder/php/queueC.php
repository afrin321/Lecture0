<?php

    session_start();

	require_once('../service/userService.php');

	if (isset($_POST['getq'])) {
		
		$p = getAppForQueue($_COOKIE['pid']);

		//echo "<table>";

		if ($p) {
			
			for ($i=0; $i <count($p) ; $i++) { 

				if ($p[$i]['queueDate']>=date("Y-m-d",time())) {

					$q = getAllSlotInfo($p[$i]['queueSlotId']);

					if ($q) {

						$r = getInfoForSlot($q['slot_consId']);
						

					}

					$date1=date_create($p[$i]['queueDate']);
					$date2=date_create(date("Y-m-d",time()));
					$diff=date_diff($date2,$date1);
					//echo $diff->format("%a days");

					
					echo "<div class=\"panel panel-default\"><div class=\"panel-body\">";
					if($diff->format("%a")>0){
						if ($diff->format("%a")==1) {
							echo "<label align=\"right\"><i>";
							echo $diff->format("%a day remaining");
							echo "</i></label>";
						}else{
							echo "<label align=\"right\"><i>";
							echo $diff->format("%a days remaining");
							echo "</i></label>";
						}
					}else{
							echo "<label><i><span style=\"color:red\">Few hours remaining</span></i></label>";
					}

					echo "<br>";
					echo "Dr. ".ucfirst($r['consName']);
					echo "<br><br>";
					$date = strtotime($p[$i]['queueDate']);
					$date = date('l', $date);
					echo $date.", ";
					
					//echo $p[$i]['queueDay'];
					//echo "<br><br>";
					
					echo $p[$i]['queueDate'];
					echo "<br><br>";
					
					echo "<a href=\"#\" onclick=\"openQueueInfo(".$p[$i]['appId'].")\">Open</a>";
					echo "<br><br>";

					echo "</div></div>";
					echo "<br>";


					
				}
		}

		//echo "</table>";

		}else{
			echo "No Appointments currently registered.";
		}
	}

	if (isset($_POST['queue_list'])) {
		
		$x = getQueueAppById($_POST['queue_list']);

		$yy = $_POST['queue_list'];

		$z = existInArrival($yy);

			if($z){

				$v = viewArrivalList($yy);

			}else{

				$w = insertIntoArrivalList($yy);

				if ($w) {
					$v = viewArrivalList($yy);
				}
				//if ($w) {
				//	echo "added";
				//}
			}

			$full_slot = getSlot($_POST['queue_list']);

		if ($x && $v) {

			if ($v['doctor_arrival_stat']=="Arrived") {
					$to_time = strtotime($full_slot['slot_start_time']);
					$from_time = strtotime($v['arrival_time']);
					$late_stat = round(abs($to_time - $from_time) / 60,2). " minutes";
			}else{
				$late_stat = "";

			}

			if ($v['late_possibility']=='') {
				$lp='N/A';
			}else{
				$lp=$v['late_possibility'];
			}

				echo "<div>";
				

				echo "</div>";

				echo "<div>";
				echo "<div class=\"panel panel-default\"><div class=\"panel-heading\">Doctor</div><div class=\"panel-body\">";
				echo 	"<div class=\"table-responsive\"><table class=\"table table-borderless\">
											<tr>
												<td><b>Doctor's Status: ".$v['doctor_arrival_stat']."</b></td>
												<td></td>
												<td>Slot: "."".date("g:i a", strtotime($full_slot['slot_start_time']))." - ".date("g:i a", strtotime($full_slot['slot_end_time'])).""."</td>
												<td></td>
											</tr>
											<tr>
												<td>Late Status: ".$late_stat."</td>
												<td></td>
												<td>Currently in Session: ".$v['cur_in_queue']."</td>
												<td></td>
											</tr>
											<tr>
												<td><label>Late possibility: ".$lp."</label></td>
												<td></td>
												<td>Next in Session: ".$v['next_in_queue']."</td>
												<td></td>
											</tr>
										</table></div>";
				echo "</div></div>";
				echo "<div class=\"panel panel-default\"><div class=\"panel-body\">";
				echo "<br>";

			for ($i=0; $i <count($x) ; $i++){

				$o = getPatientInfo($x[$i]['pid']);

				if ($o['p_gender']=='male') {
					$cred = 'Mr. ';
				}elseif($o['p_gender']=='female'){
					$cred = 'Miss./Mrs. ';
				}else{
					$cred = "Mr./Miss. ";
				}

				if ($x[$i]['pArrival'] == "00:00:00.000000" ) {
					$a_stat = "Default";
					$c_stat = $x[$i]['pApStatus'];
				}else{
					$a_stat = "Arrived";//."  "."<i><img src=\"check.png\" width=\"18\" height=\"18\"></i>";
					$c_stat = "Waiting";

					
				}

				if($a_stat == "Arrived" && $x[$i]['pApStatus'] == "Default"){
					$c_name = "queue_div";
				}elseif($x[$i]['pApStatus'] == "Next in Queue" || $x[$i]['pApStatus'] == "Calling to join session"){
					$c_name = "next_queue_div";
				}elseif($x[$i]['pApStatus'] == "Default" && $a_stat = "Default"){
					$c_name = "unarrived";//"alert alert-danger";
				}elseif($a_stat == "Arrived" && $x[$i]['pApStatus'] == "Currently in session"){
					$c_name = "in_sess";

				}else{
					$c_name = "queue_div";
				}
				echo "<br><br>";

				echo "<div class=\"".$c_name."\">";



				
				//echo "<fieldset>";

				if ($x[$i]['pid']==$_COOKIE['pid']) {
					echo "<b><span class=\"label label-danger\">Your Position</span></b>";
					echo "<hr>";//style=\"color:red\"
					//echo "hii";
				}

				//echo "<br>";				
				echo "Queue Position: <span class=\"label label-info\">".$x[$i]['pQueue']."</span>";
				echo "<br><br>";
				echo "Name: ".$cred." ".ucfirst($o['p_firstName'])." ".ucfirst($o['p_lastName']);
				echo "<br><br>";
				echo "Arrival Status: ".$a_stat;
				if ($a_stat=="Arrived") {
					echo "<i>  at ".date("g:i a", strtotime($x[$i]['pArrival']))."</i>";
					echo "  "."<i><img src=\"check.png\" width=\"18\" height=\"18\"></i>";
				}
				echo "<br><br>";
				echo "Current Status: ".$x[$i]['pApStatus'];
				if ($x[$i]['pApStatus'] == "Currently in session") {
					echo "  "."<i><img src=\"do-not-disturb.png\" width=\"18\" height=\"18\"></i>";
				}
				if ($x[$i]['pApStatus'] == "Completed") {
					echo "<i>  at ".date("g:i a", strtotime($x[$i]['pComplete']))."</i>";
					echo "  "."<i><img src=\"check.png\" width=\"18\" height=\"18\"></i>";					
				}
				//echo "<br><br>";
				//echo "Current Status: ".$x[$i]['pApStatus'];
				echo "<br>";
				/*echo "<br><br>";
				echo "Queue Position: ".$x[$i]['pQueue'];
				echo "<br><br>";
				echo "Arrival Status: ".$x[$i]['pApStatus'];
				echo "<br><br>";*/
				//echo 
				echo "</div>";

			}
			echo "</div>";
				
			echo "</div>";
			echo "<br><br>";
			
		}
	}

	

	

	

	


?>