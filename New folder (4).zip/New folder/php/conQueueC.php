<?php

    session_start();

	require_once('../service/userService.php');

	if (isset($_POST['allq'])) {

		if(isset($_COOKIE['qidforcon'])){

			$y = $_COOKIE['qidforcon'];
			//echo $y;
			//setcookie("qidforcon", "", time()-600, "/");

		
		
		

		if ($y) {
			
			$x = getQueueAppByIdCon($y);
			$z = existInArrival($y);

			if($z){

				$v = viewArrivalList($y);

			}else{

				$w = insertIntoArrivalList($y);
				if ($w) {
					$v = viewArrivalList($y);
				}			

				//if ($w) {
				//	echo "added";
				//}
			}

			//echo $y;

			//count($x);
			$full_slot = getSlot($y);

		if ($x && $v) {
			if ($v['doctor_arrival_stat']=="Arrived") {
					$to_time = strtotime($full_slot['slot_start_time']);
					$from_time = strtotime($v['arrival_time']);
					$late_stat = round(abs($to_time - $from_time) / 60,2). " minutes";
			}else{
				$late_stat = "";

			}

			// if ($v['doctor_arrival_stat']=="Arrived") {

			// }else{
			// 	$a_info = ""
			// }



			//$late_stat = 


				echo "<div>";
				

				echo "</div>";

				echo "<div>";
				echo "<div class=\"table-responsive\">";
				echo 	"<table class=\"table\">
											<tr>
												<td><b>Doctor's Status: <span class=\"label label-success\">".$v['doctor_arrival_stat']."</span></b></td>
												<td><select id=\"dstat\">
													<option value=\"Arrived\">Arrived</option>
													<option value=\"Will be late\">Will be late</option>
													<option value=\"Almost there\">Almost there</option>
													<option value=\"Default\">Default</option>
												</select>
												</td>
												<td>Slot: "."".date("g:i a", strtotime($full_slot['slot_start_time']))." - ".date("g:i a", strtotime($full_slot['slot_end_time'])).""."</td>
												<td></td>
											</tr>
											<tr>
												<td>Late Status: ".$late_stat."</td>
												<td></td>
												<td>Currently in Session: ".$v['cur_in_queue']."</td>
												<td></td>
											</tr>
											<tr>
												<td><label>Late possibility: ".$v['late_possibility']." </label></td>
												<td><input type=\"text\" placeholder=\"5 minutes\" id=\"lp\"></td>
												<td>Next in Session: ".$v['next_in_queue']."</td>
												<td></td>
											</tr>";
				//echo 	"<input type=\"button\" value=\"Update\" onclick=\"updateList(".$y.")\" class=\"btn btn-primary\"><label id=\"res2\"></label>";
				echo "</table></div>";
				echo 	"<input type=\"button\" value=\"Update\" onclick=\"updateList(".$y.")\" class=\"btn btn-primary\"><label id=\"res2\"></label>";
				echo "<div>";
				echo "<br><br>";

			for ($i=0; $i <count($x) ; $i++){

				$o = getPatientInfo($x[$i]['pid']);

				if ($o['p_gender']=='male') {
					$cred = 'Mr. ';
				}elseif($o['p_gender']=='female'){
					$cred = 'Miss./Mrs. ';
				}else{
					$cred = "Mr./Miss. ";
				}

				//echo var_dump($x[$i]['pArrival']);
				if ($x[$i]['pArrival'] == "00:00:00.000000" ) {
					$a_stat = "Default";
					$c_stat = $x[$i]['pApStatus'];
				}else{
					$a_stat = "Arrived";//."  "."<i><img src=\"check.png\" width=\"18\" height=\"18\"></i>";
					$c_stat = "Waiting";					
				}


				if($a_stat == "Arrived" && $x[$i]['pApStatus'] == "Default"){
					$c_name = "queue_div";
				}elseif($v['next_in_queue'] == $x[$i]['pQueue'] || $x[$i]['pApStatus'] == "Calling to join session"){
					$c_name = "next_queue_div";
				}elseif($x[$i]['pApStatus'] == "Default" && $a_stat = "Default"){
					$c_name = "unarrived";
				}elseif(($a_stat == "Arrived") && ($x[$i]['pApStatus'] == "Currently in session")){
					$c_name = "in_sess";
				}else{
					$c_name = "queue_div";
				}

				echo "<div class=\"".$c_name."\">";
				//echo "<fieldset>";
				//echo $c_name;
								
				echo "<br>";				
				echo "Queue Position: <span class=\"label label-info\">".$x[$i]['pQueue']."</span>";
				echo "<br><br>";
				echo "Name: ".$cred." ".ucfirst($o['p_firstName'])." ".ucfirst($o['p_lastName']);
				echo "<br><br>";
				echo "Arrival Status: ".$a_stat;
				if ($a_stat=="Arrived") {
					echo "<i>  at ".date("g:i a", strtotime($x[$i]['pArrival']))."</i>";
					echo "  "."<i><img src=\"check.png\" width=\"18\" height=\"18\"></i>";
				}
				echo "<br><br>";
				echo "Current Status: ".$x[$i]['pApStatus'];
				if ($x[$i]['pApStatus'] == "Currently in session") {
					echo "  "."<i><img src=\"do-not-disturb.png\" width=\"18\" height=\"18\"></i>";
				}
				if ($x[$i]['pApStatus'] == "Completed") {
					echo "<i>  at ".date("g:i a", strtotime($x[$i]['pComplete']))."</i>";
					echo "  "."<i><img src=\"check.png\" width=\"18\" height=\"18\"></i>";					
				}
				//echo "<br><br>";
				
				echo "<br>";
				if (($a_stat=='Arrived'||$a_stat=='Waiting')&&($x[$i]['pApStatus']=='Next in Queue')) {
					echo "<input type=\"button\" value=\"Call to Join\" onclick=\"callP(".$x[$i]['pQueue'].",".$x[$i]['appId'].",".$x[$i]['pid'].")\" class=\"btn btn-primary\">";
					//echo "<label> Calling <b>Serial ".$x[$i]['pQueue']."</b> to join Appointment</label>";
				}elseif (($a_stat=='Arrived'||$a_stat=='Waiting')&&($x[$i]['pApStatus']=='Calling to join session')) {
					echo "<input type=\"button\" value=\"Joined\" onclick=\"joinP(".$x[$i]['pQueue'].",".$x[$i]['appId'].")\" class=\"btn btn-primary\">";
					echo "   ";
					echo "<input type=\"button\" value=\"Cancel\" onclick=\"cancelP(".$x[$i]['pQueue'].",".$x[$i]['appId'].")\" class=\"btn btn-primary\">";
					//echo "<br> <label id=\"after_call\"></label>";
				}
				if ($x[$i]['pApStatus']=='Currently in session') {
					echo "<br><br>";
					echo "<input type=\"button\" value=\"Mark Completed\" onclick=\"markP(".$x[$i]['pQueue'].",".$x[$i]['appId'].",".$x[$i]['pid'].")\" class=\"btn btn-primary\">";
				}
				//echo "<input type=\"button\" value=\"Call to Join\" onclick=\"arrivedUp(".$x[$i]['pid'].",".$x[$i]['appId'].")\">";
				//echo "<label id=\"arrival_stat\"></label>";
								
				echo "<br>";
				//echo "</fieldset>";
				echo "</div>";

				//echo "</div>";
				echo "<br><br>";



				
				/*echo "<fieldset>";

				
				echo "<br><br>";
				echo "Queue Position: ".$x[$i]['pQueue'];
				echo "<br><br>";
				echo "Arrival Status: ".$x[$i]['pApStatus'];
				echo "<br><br>";
				//echo 
				echo "</fieldset>";
				echo "</div>";
				echo "<br><br>";*/
			}

			echo "</div></div>";
			
		}else{
			echo "Appointment info not found. This may be because queue is empty";
		}

	}else{
		echo "Please select specific appointment from Home or Appointments section.";
	}
	}
}

	if (isset($_POST['upd'])) {

		if (empty($_POST['q'])||empty($_POST['s'])||empty($_POST['l'])) {
			//echo "empty";
		}

		$data = [
			'q'=>$_POST['q'],
			's'=>$_POST['s'],
			'l'=>$_POST['l']
		];
		
		$m = updateArrivalList($data);

		if ($m) {
			echo "Updated succesfully";
		}else{
			echo "Some error in system";
		}
	}

	if (isset($_POST['calltojoin'])) {

		$data = [
			'qid'=>$_POST['appid'],
			'pq'=>$_POST['pid']
		];

		$v = updatepApStatus($data);

		$data2 = [
			'p'=>$_POST['p'],
			'm'=>"Please join Session with Doctor.",
			'title'=>'Call'
		];

		$u = notificationOne($data2);

		if ($v && $u) {
			echo "yes";
		}else{
			echo "no";
		}
	}

	if (isset($_POST['joined'])) {
		$data = [
			'qid'=>$_POST['appid'],
			'pq'=>$_POST['pid']
		];

		$t = updatepApStatusTwo($data);
		$s = updateDocArrivalTwo($data);

		if ($t && $s) {
			echo "yes";
		}else{
			echo "no";
		}

	}

	if (isset($_POST['mark'])) {

		$data = [
			'qid'=>$_POST['appid'],
			'pq'=>'Default'
		];

		//$t = updatepApStatusTwo($data);
		$r = updateDocArrivalTwo($data);

		$data2 = [
			'qid'=>$_POST['appid'],
			'pq'=>$_POST['pid']
		];

		$q = updatepApStatusThree($data2);

		$data3 = [
			'appid'=>$_POST['appid'],
			'pid'=>$_POST['p']
		];

		$p = updateCompletionAppqueue($data3);


		if ($q && $r && $p) {
			echo "yes";
		}else{
			echo "no";
		}

		
	}

?>