<?php

    session_start();

	require_once('../service/userService.php');

	if(isset($_POST['getlog'])){

		//echo "hi";

		$p = $_COOKIE['pid'];
		//echo $p;

		$x = getAllLog($p);
		//$y = 

		if ($x) {
			
			//$t = time();
			//echo(date("d-m-Y",$t));

			//$tempDate = date("d-m-Y",$t);
			//echo "    ";
			//$t2 = date('l', strtotime($tempDate));

			//$Date1 = $tempDate;

			//$t = time();
			//echo $t;

					//echo(date("d-m-Y",$t));

					//$t = strtotime($x[0]['queueDate']);

					//$tempDate = date("d-m-Y",$t);
					//echo "    ";
					//echo $x[0]['queueDate'];
					//echo var_dump($x[0]['queueDate']);

					//$t2 = date('l', strtotime($tempDate));
					//$Date1 = $tempDate;

			


				for ($i=0; $i < count($x); $i++) {  	
					$t = strtotime($x[$i]['queueDate']);

					$tempDate = date("d-m-Y",$t);
					$Date1 = $tempDate;

			

					if (isset($month1)) {
						if ($month1!=date("F", strtotime($Date1))) {

							echo "</table></div></div>";

							$month1 = date("F", strtotime($Date1));
							$year1 = date("o", strtotime($Date1));
					        echo "<h3>".$month1." ".$year1."</h3>";	
					        echo "<div class=\"table-responsive-sm\"><table class=\"table\">";
					        echo "<tr><th>Date</th><th>Consultant</th><th>Time</th><th>Payment</th><th>Attendance</th><th>Cancelallation</th></tr>";				    
						}
					}else{

						$month1 = date("F", strtotime($Date1));
					    $year1 = date("o", strtotime($Date1));
					    echo "<h3>".$month1." ".$year1."</h3>";
					    echo "<div class=\"table-responsive-sm\"><table class=\"table\">";
					    echo "<tr><th>Date</th><th>Consultant</th><th>Time</th><th>Payment</th><th>Attendance</th><th>Cancelallation</th></tr>";

					}

					$date = date_create($x[$i]['queueDate']);

					$res = conNameForLog($x[$i]['queueSlotId']);
					$res2 = getAllSlotInfo($x[$i]['queueSlotId']);

					//echo "<br>";
					echo "<tr>";
					// echo "<div class=\"table-responsive-sm\"><table class=\"table\"><tr>";
					echo "<td>".date_format($date, 'l, M d Y')."</td>";
					echo "<td>"."Dr. ".$res['consName']."</td>";
					echo "<td>".date("g:i ", strtotime($res2['slot_start_time']))." - ".date("g:i a", strtotime($res2['slot_end_time']))."</td>";
					echo "<td>".$x[$i]['pFee']."</td>";
					echo "<td>".$x[$i]['pApStatus']."</td>";
					if($x[$i]['pApStatus']=='Default' && (date("Y-m-d")<$x[$i]['queueDate'])){
						echo "<td><a href=\"#\" onclick=\"cancelLog(".$x[$i]['appId'].",".$x[$i]['pid'].",".$res['consName'].",".$x[$i]['pQueue'].")\">Cancel Appointment</a>"."</td>";
					}else{
						echo "<td></td>";
					}
					echo "</tr>";

					//echo "<td><a href=\"#\">Open Queue</a>"." | "."<a href=\"#\">Cancel</a>"."</td>";
					// echo "</tr></table></div></div>";



				//echo $x[$i]['pApStatus'];
				//echo "<br>";





				}
		}else{
			echo "not found";
		}
	}

	if (isset($_POST['cancel'])) {
		$data = [
			'app'=>$_POST['app'],
			'pid'=>$_POST['pid'],
			'dn'=>$_POST['dn'],
			'q'=>$_POST['q']
		];

		$dn = $_POST['dn'];

		$m = cancelFromQueue($data);

		if ($m){
			echo "true";
		}else{
			echo "false";
		}
	}





?>