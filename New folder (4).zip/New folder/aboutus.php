<!DOCTYPE html>
<html>
<head>
	<title>About Us</title>
	   	<meta charset="utf-8">
  		<meta name="viewport" content="width=device-width, initial-scale=1">
  		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  
		<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
		<link rel="stylesheet" href="homestyle.css">
</head>
<body>
	<div class="container-fluid">
	
	
	



	<div class="container-fluid">
			<ul class="up">
	<!-- 		<li class="up">
				<a href="views/Patient/patientLogin.php" class="up">Log In</a>
			</li>
			<li class="up">
				<a href="views/Patient/patientRegister.php" class="up">Register</a>
			</li> -->
			<li class="left"><img src="logo.png" class="img-fluid" class="left"></li>
			<li class="up"><a href="views/Patient/patientLogin.php" class="up"><span class="glyphicon glyphicon-user"></span>Login</a></li>
			<li class="up"><a href="views/Patient/patientRegister.php" class="up"><span class="glyphicon glyphicon-log-in"></span>Register</a></li>
		</ul>
	</div>
	<br>
	<nav class="navbar">
  	<div class="container-fluid">
    
		<ul class="menu nav navbar-nav">
			<li class="menu">
				<a href="index.php" class="menu"><i class="material-icons">home</i>  Home</a>
			</li>
			<li class="menu">
				<a href="" class="menu">About Us</a>
			</li>
			<li class="menu">
				<a href="" class="menu">Consultants</a>
			</li>
			<li class="menu">
				<a href="views/appointment.php" class="menu">Appointment</a>
			</li>
			<li class="menu">
				<a href="" class="menu">Services</a>
			</li>
			<li class="menu">
				<a href="contact.php" class="menu">Contact Us</a>
			</li>			
		</ul>
		
		
	</div>
	</nav>	
	<br>
	<div class="container">
		
		<div class="container sec_d" >
			<br>
			<br>
		</div>	
		
		<div class="container">
			<br>
			<h1>About Us</h1>
			<br>

			<p><strong>ApSys</strong>, an Appointment Management System is a web application that aids in managing the appointment process in a way that makes it convenient for both the clients as well as the organization. It helps in tackling the problems related to wave scheduling of appointments.</p>
			<br>
			<p>The web-based appointment management system provides a solution to a number of issues faced by outdoor patients when they make an appointment, as well as, give required support to the OPD to tackle necessary tasks. An appointment management system allows online booking of appointments and contain features that enable a smooth flow of all related processes. It is targeted to solve problems associated with wave scheduling of appointments and enhance user experience.</p>
			<br>
			<p>This project is built for an organization, particularly focusing on hospitals and clinics, aiming to improve its’ appointment management to provide better service to its’ clients and bring about more efficient operations within the system. The users of the system include the patients <i>clients</i> of the organization, the health specialist <i>consultants</i> to whom appointments are made, attendants, who are a part of the appointment management system and an admin for being in-charge of the system and over-looking all tasks.</p>
			<br>
			<p>
				Benefits of using ApSys
				
				<ul>
					<li>24/7 access availability to customers</li>
					<li>Faster appointments can be made</li>
					<li>Real-time queue information available to customers</li>
					<li>Reduces waiting time of customers by presenting queue information</li>
					<li>More flexibility and peace of mind for customers.</li>
					<li>Better customer experience.</li>
					<li>Control over arrival flow and customer footfall on premises.</li>
					<li>Hassle free cancellations</li>
					<li>Less paperwork</li>
					<li>Premises less crowded</li>
				</ul>
			</p>

		</div>	
		<br><br>
		<div class="container sec_d" >
				<br>
				<br>
			</div>
			<br>
		</div>

	


<!-- 	<div class="sec_d container-fluid">>
		<label class="sec_d"><b> Welcome to ApSys Clinic </b></label>
		<br>
		<br>
		<br>
		<br>
		<p>Lorem</p>
	</div> -->
	
	

	

	





	
	<br>
	<div class="footer">
			<div>
				<h4 align="center">Copyright@2021</h4>
			</div>
	</div>
		
	

	

</body>
</html>