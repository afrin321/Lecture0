<?php
	
	require_once('../db/db.php');
	
	/*function getById($id){
		$con = dbConnection();
		$sql = "select * from empinfo where id='{$id}'";
		$result = mysqli_query($con, $sql);
		$row = mysqli_fetch_assoc($result);
		return $row;
	}
	
	function getAllUser(){
		$con = dbConnection();
		$sql = "select * from empinfo";
		$result = mysqli_query($con, $sql);
		$users =[];
		while($row = mysqli_fetch_assoc($result)){
			array_push($users, $row);
		};
		return $users;
	}

	function getByName($name){
		$con = dbConnection();
		$sql = "select * from empinfo where username like '%{$name}%'";
		$result = mysqli_query($con, $sql);
		$row = mysqli_fetch_assoc($result);
		$users =[];
		while($row = mysqli_fetch_assoc($result)){
			array_push($users, $row);
		};
		return $users;

	}



		function getByEmpName($name){
		$con = dbConnection();
		$sql = "select * from empinfo where emp_name like '%{$name}%'";
		$result = mysqli_query($con, $sql);
		$row = mysqli_fetch_assoc($result);
		$users =[];
		while($row = mysqli_fetch_assoc($result)){
			array_push($users, $row);
		};
		return $users;

	}

		function getByCompName($name){
		$con = dbConnection();
		$sql = "select * from empinfo where comp_name like '%{$name}%'";
		$result = mysqli_query($con, $sql);
		$row = mysqli_fetch_assoc($result);
		$users =[];
		while($row = mysqli_fetch_assoc($result)){
			array_push($users, $row);
		};
		return $users;

	}*/

	/*function compareQueueMax(){

		$con = dbConnection();
		$sql = "select * from syscons where deptID in (select deptID from sysdept where deptName='{$name}')";
		$result = mysqli_query($con, $sql);
		if ($result) {
			return true;
		}else{
			return false;
		}

	}*/
	// function checkQueue($data){

	// }
	function attTotalList($data){
		$con = dbConnection();
		$sql = "select * from attslot inner join slot on attslot.slot_id = slot.slot_id where att_id='{$data}'";
		$result = mysqli_query($con, $sql);
		$c = [];
		if ($result) {
			while($row = mysqli_fetch_assoc($result)){
			array_push($c, $row);
		};
		return $c;
		}else{
			return false;
		}
	}

	function changePwAtt($data){
		$con = dbConnection();
		$sql = "update att_info set att_pw='{$data['pw']}' where att_id='{$data['id']}'";
		$result = mysqli_query($con, $sql);
		if ($result) {
			return true;
		}else{
			return false;
		}
	}

	function checkAtt($data){
		$con = dbConnection();
		$sql = "select count(*) from att_info where att_id='{$data['id']}' and att_pw='{$data['pw']}'";
		$result = mysqli_query($con, $sql);
		if ($result) {
			$row = mysqli_fetch_assoc($result);
			if($row['count(*)']>0){
				return true;
			}else{
				return false;
			}
		}else{
			return false;
		}
	}

	function changePwCons($data){
		$con = dbConnection();
		$sql = "update conscredentials set consPw='{$data['pw']}'and stat='changed' where consId='{$data['id']}'";
		$result = mysqli_query($con, $sql);
		if ($result) {
			return true;
		}else{
			return false;
		}
	}

	function checkCons($data){
		$con = dbConnection();
		$sql = "select count(*) from conscredentials where consId='{$data['id']}' and consPw='{$data['pw']}'";
		$result = mysqli_query($con, $sql);
		if ($result) {
			$row = mysqli_fetch_assoc($result);
			if($row['count(*)']>0){
				return true;
			}else{
				return false;
			}
		}else{
			return false;
		}
	}

	function changePwPatient($data){
		$con = dbConnection();
		$sql = "update patientreg set p_pw='{$data['pw']}' where patient_Id='{$data['id']}'";
		$result = mysqli_query($con, $sql);
		if ($result) {
			return true;
		}else{
			return false;
		}
	}

	function checkPatient($data){
		$con = dbConnection();
		$sql = "select count(*) from patientreg where patient_Id='{$data['id']}' and p_pw='{$data['pw']}'";
		$result = mysqli_query($con, $sql);
		if ($result) {
			$row = mysqli_fetch_assoc($result);
			if($row['count(*)']>0){
				return true;
			}else{
				return false;
			}
		}else{
			return false;
		}
	}

	function changePwAdmin($data){
		$con = dbConnection();
		$sql = "update admin_table set aPassword='{$data['pw']}' where adminID='{$data['id']}'";
		$result = mysqli_query($con, $sql);
		if ($result) {
			return true;
		}else{
			return false;
		}
	}

	function checkAdmin($data){
		$con = dbConnection();
		$sql = "select count(*) from admin_table where adminID='{$data['id']}' and aPassword='{$data['pw']}'";
		$result = mysqli_query($con, $sql);
		if ($result) {
			$row = mysqli_fetch_assoc($result);
			if($row['count(*)']>0){
				return true;
			}else{
				return false;
			}
		}else{
			return false;
		}
	}

	function getPayBySlot($data){
		$con = dbConnection();
		$sql = "select slot_fee from slot where slot_id='{$data}'";
		$result = mysqli_query($con, $sql);
		if ($result) {
			$row = mysqli_fetch_assoc($result);		
		return $row;
		}else{
			return false;
		}
	}

	function getSlotForCancel($data){
		$con = dbConnection();
		$sql = "select * from queueinitialize inner join slot where queueinitialize.queueDate='{$data['d']}' and slot.slot_consId='{$data['c']}' and slot.slot_id=queueinitialize.queueSlotId and queueinitialize.queueStatus='Active' and queueinitialize.queueDate>='{$data['d']}'";
				$result = mysqli_query($con, $sql);
		$c = [];
		if ($result) {
			while($row = mysqli_fetch_assoc($result)){
			array_push($c, $row);
		};
		return $c;
		}else{
			return false;
		}
	}

	function delCon($data){
		$con = dbConnection();
		$sql = "update syscons set consStat='Deactive' where ConsID='{$data}'";
		$result = mysqli_query($con, $sql);
		if ($result) {
			return true;
		}else{
			return false;
		}
	}

	function deleteSlot($data){
		$con = dbConnection();
		$sql = "update slot set slot_Status='Deactivated' where slot_id='{$data}'";
		$result = mysqli_query($con, $sql);
		if ($result) {
			return true;
		}else{
			return false;
		}
	}

	function cancelforSlot($data){
		$con = dbConnection();
		$sql = "update queueinitialize set queueStatus='Cancelled' where queueSlotId='{$data}' and queueDate>CURRENT_DATE";
		$result = mysqli_query($con, $sql);
		if ($result) {
			return true;
		}else{
			return false;
		}
	}

	function listcancelslot($data){
		$con = dbConnection();
		$sql = "select * from queueinitialize where queueSlotId='{$data}' and queueDate>CURRENT_DATE";
		$result = mysqli_query($con, $sql);
		$c = [];
		if ($result) {
			while($row = mysqli_fetch_assoc($result)){
			array_push($c, $row);
		};
		return $c;
		}else{
			return false;
		}
	}

	function deleteAttSlot($data){
		$con = dbConnection();
		$sql = "delete from att slot where slot_id='{$data}'";
		$result = mysqli_query($con, $sql);
		if ($result) {
			return true;
		}else{
			return false;
		}
	}

	function listcancelslotTwo($data){
		$con = dbConnection();
		$sql = "select * from queueinitialize where queueSlotId='{$data}' and queueDate>=CURRENT_DATE";
		$result = mysqli_query($con, $sql);
		$c = [];
		if ($result) {
			while($row = mysqli_fetch_assoc($result)){
			array_push($c, $row);
		};
		return $c;
		}else{
			return false;
		}
	}

	

	function getSlot($data){
		$con = dbConnection();
		$sql = "select * from slot where slot_id=(select queueSlotId from queueinitialize where queueId='{$data}')" ;
				$result = mysqli_query($con, $sql);
		if ($result) {
			$row = mysqli_fetch_assoc($result);
		
		return $row;
		}else{
			return false;
		}
	}

	function getBalance($data){
		$con = dbConnection();
		$sql = "select * from patient_payment where pid='{$data}'";
		$result = mysqli_query($con, $sql);
		if ($result) {
			$row = mysqli_fetch_assoc($result);
		
		return $row;
		}else{
			return false;
		}
	}
	
	function countWaitQueue($data){
		$con = dbConnection();
		$sql = "select count(*) from waitqueue where app_id='{$data}'";
		$result = mysqli_query($con, $sql);
		if ($result) {
			$row = mysqli_fetch_assoc($result);
			return $row['count(*)'];
		}else{
			return false;
		}
	}

	function cancelFromQueue($data){
		$con = dbConnection();
		$sql = "delete from appqueue where appId='{$data['app']}' and pid='{$data['pid']}' and pQueue='{$data['q']}'";
		
		$result = mysqli_query($con, $sql);
		if ($result) {

			$sql = "update appqueue set pQueue=pQueue-1 where pQueue>'{$data['q']}' and appId='{$data['app']}'";

			// $sql = "delete from appqueue where appId='{$data['app']}' and pid='{$data['pid']}' and pQueue='{$data['q']}'";
			$result2 = mysqli_query($con, $sql);

			if ($result2) {
				$sql = "update queueinitialize set queueCurQuantity=(select count(*) from appqueue where appId='{$data['app']}') where queueId='{$data['app']}'";
				$result3 =  mysqli_query($con, $sql);

				if ($result3) {
					return true;
				}else{
					return false;
				}
			}else{
				return false;
			}
			
		}else{
			return false;
		}
	}

	function updateCompletionAppqueue($data){
		$con = dbConnection();
		$sql = "update appqueue set pComplete=now() where appId='{$data['appid']}' and pid='{$data['pid']}'";
		$result = mysqli_query($con, $sql);
		if ($result) {
			return true;
		}else{
			return false;
		}

	}


	function updatepApStatusThree($data){
		$con = dbConnection();
		$sql = "update appqueue set pApStatus='Completed' where pQueue='{$data['pq']}' and appId='{$data['qid']}'";
		$result = mysqli_query($con, $sql);
		if ($result) {
			return true;
		}else{
			return false;
		}
	}

	function updateDocArrivalTwo($data){
		$con = dbConnection();
		$sql = "update doctorarrival set cur_in_queue='{$data['pq']}' where qid='{$data['qid']}'";
		$result = mysqli_query($con, $sql);
		if ($result) {
			return true;
		}else{
			return false;
		}
	}

	function updatepApStatusTwo($data){
		$con = dbConnection();
		$sql = "update appqueue set pApStatus='Currently in session' where pQueue='{$data['pq']}' and appId='{$data['qid']}'";
		$result = mysqli_query($con, $sql);
		if ($result) {
			return true;
		}else{
			return false;
		}
	}

	function notifyFour($data){
		$con = dbConnection();
		$sql = "select count(*) from pnotify where pid='{$data}' and title='Call'";
		$result = mysqli_query($con, $sql);
		$row = mysqli_fetch_assoc($result);
		if ($result) {
			if ($row['count(*)']>0) {
				return true;
			}else{
				return false;
			}
		}else{
			return false;
		}
	}

	function updateDocArrival($data){
		$con = dbConnection();
		$sql = "update doctorarrival set next_in_queue='{$data['pq']}' where qid='{$data['qid']}'";
		$result = mysqli_query($con, $sql);
		if ($result) {
			return true;
		}else{
			return false;
		}
	}

	function updateDocArrivalThree($data){
		$con = dbConnection();
		$sql = "update doctorarrival set next_in_queue='Default' where qid='{$data['qid']}'";
		$result = mysqli_query($con, $sql);
		if ($result) {
			return true;
		}else{
			return false;
		}
	}

	function updateAppQueueNext($data){
		$con = dbConnection();
		$sql = "update appqueue set pApStatus='Next in Queue' where pQueue='{$data['pq']}' and appId='{$data['qid']}'";
		$result = mysqli_query($con, $sql);
		if ($result) {
			return true;
		}else{
			return false;
		} 
	}

	function updateAppQueueNextTwo($data){
		$con = dbConnection();
		$sql = "update appqueue set pApStatus='Default' where pQueue='{$data['pq']}' and appId='{$data['qid']}'";
		$result = mysqli_query($con, $sql);
		if ($result) {
			return true;
		}else{
			return false;
		} 
	}

	function updatepApStatus($data){
		$con = dbConnection();
		$sql = "update appqueue set pApStatus='Calling to join session' where pQueue='{$data['pq']}' and appId='{$data['qid']}'";
		$result = mysqli_query($con, $sql);
		if ($result) {
			return true;
		}else{
			return false;
		}
	}



	function updateArrivalAppqueue($data){
		$con = dbConnection();
		$sql = "update appqueue set pArrival=now() where appId='{$data['appid']}' and pid='{$data['pid']}'";
		$result = mysqli_query($con, $sql);
		if ($result) {
			return true;
		}else{
			return false;
		}

	}

	function getPatientInfo($data){
		$con = dbConnection();
		$sql = "select * from patientreg where patient_Id='{$data}'";
		$result = mysqli_query($con, $sql);
		if ($result) {
			$row = mysqli_fetch_assoc($result);
		
		return $row;
		}else{
			return false;
		}
	}

	function slotinfoAtt($data){
		$con = dbConnection();
		$sql = "select * from slot where slot_id='{$data}'";
		$result = mysqli_query($con, $sql);
		if ($result) {
			$row = mysqli_fetch_assoc($result);
		
		return $row;
		}else{
			return false;
		}
	}

	function attQinfoHome($data){
		$con = dbConnection();
		$sql = "select * from queueinitialize where queueSlotId='{$data}' and queueDate=curdate() and queueStatus='Active'";// and queueStatus='Active'"
		$result = mysqli_query($con, $sql);
		$c = [];
		if ($result) {
			while($row = mysqli_fetch_assoc($result)){
			array_push($c, $row);
		};
		return $c;
		}else{
			return false;
		}

	}

	function attTodayList($data){
		$con = dbConnection();
		$sql = "select * from attslot inner join slot on attslot.slot_id = slot.slot_id where att_id='{$data}' and slot.slot_day=lower(dayname(curdate()))";
		$result = mysqli_query($con, $sql);
		$c = [];
		if ($result) {
			while($row = mysqli_fetch_assoc($result)){
			array_push($c, $row);
		};
		return $c;
		}else{
			return false;
		}
	}

	function updatePw($data){
		$con = dbConnection();
		$sql = "update att_info set att_pw='{$data['pw']}' where att_id='{$data['id']}'";
		$result = mysqli_query($con, $sql);
		if ($result) {
			return true;
		}else{
			return false;
		}
	}

	function validateAttLogin($data){
		$con = dbConnection();
		$sql = "select count(*) from att_info where att_id='{$data['uid']}' and att_pw='{$data['pw']}'";
		$result = mysqli_query($con, $sql);
		$row = mysqli_fetch_assoc($result);
		if ($result) {
			if ($row['count(*)']>0) {
				return true;
			}else{
				return false;
			}
		}else{
			return false;
		}
	}

	function viewAttSlotInfo($data){
		$con = dbConnection();
		$sql = "select * from attslot inner join slot on attslot.slot_id = slot.slot_id where att_id='{$data}' order by attslot.slot_id";
		$result = mysqli_query($con, $sql);
		
		$c = [];
		if ($result) {
			while($row = mysqli_fetch_assoc($result)){
			array_push($c, $row);
		};
		return $c;
		}else{
			return false;
		}
	}

	function viewAttSlotInfoTwo($data){
		$con = dbConnection();
		$sql = "select * from attslot inner join slot on attslot.slot_id = slot.slot_id where att_id='{$data}' and slot.slot_Status='active' order by attslot.slot_id";
		$result = mysqli_query($con, $sql);
		
		$c = [];
		if ($result) {
			while($row = mysqli_fetch_assoc($result)){
			array_push($c, $row);
		};
		return $c;
		}else{
			return false;
		}
	}

	function deleteAtt($data){
		$con = dbConnection();
		$sql = "delete from attslot where slot_id='{$data['sid']}' and att_id='{$data['atid']}'";
		$result = mysqli_query($con, $sql);
		
		if ($result) {			
			return true;
		}else{
			return false;
		}
	}
	

	function addAttInfo($data){
		$con = dbConnection();
		$sql = "insert into attslot values('', '{$data['s']}', '{$data['a']}', '')";
		$result = mysqli_query($con, $sql);
		
		if ($result) {			
			return true;
		}else{
			return false;
		}

	}

	function conName($data){
		$con = dbConnection();
		$sql = "select consName from syscons where ConsID='{$data}'";
		$result = mysqli_query($con, $sql);
		
		if ($result) {			
			$row = mysqli_fetch_assoc($result);
			return $row['consName'];
		}else{
			return false;
		}

	}

	function slotInfoSearch($data){
		$con = dbConnection();
		$sql = "select * from slot where slot_id like '%{$data}%' or slot_day like '%{$data}%' or slot_consId = (select ConsID from syscons where consName like '%{$data}%' and consStat='' limit 1) order by slot_id";
		$result = mysqli_query($con, $sql);
		
		if ($result) {			
			return $result;
		}else{
			return false;
		}
	}

		function slotInfoSearchTwo($data){
		$con = dbConnection();
		$sql = "select * from slot where slot_id like '%{$data}%' or slot_day like '%{$data}%' or slot_consId = (select ConsID from syscons where consName like '%{$data}%' and consStat='' limit 1) and slot.slot_Status='active' order by slot_id";
		$result = mysqli_query($con, $sql);
		
		if ($result) {			
			return $result;
		}else{
			return false;
		}
	}

	function searchList($data){
		$con = dbConnection();
		$sql = "select * from att_info where att_fn like '%{$data}%' or att_ln like '%{$data}%' or att_id like '%{$data}%' or concat(att_fn, ' ', att_ln) like '%{$data}%'";
		$result = mysqli_query($con, $sql);
		
		if ($result) {
			
		return $result;
		}else{
			return false;
		}
	}

	function attList(){
		$con = dbConnection();
		$sql = "select * from att_info order by att_id";
		$result = mysqli_query($con, $sql);
		$c = [];
		if ($result) {
			while($row = mysqli_fetch_assoc($result)){
			array_push($c, $row);
		};
		return $c;
		}else{
			return false;
		}


	}

	function addAttendant($data){
		$con = dbConnection();
		$sql = "insert into att_info values('', '{$data['fn']}',  '{$data['ln']}',  '{$data['dob']}', '{$data['g']}', '{$data['pn']}', '{$data['em']}',  '{$data['q']}', '', '', 'Active', '')";
		$result = mysqli_query($con, $sql);
		if ($result) {
			$last_id = mysqli_insert_id($con);
			return $last_id;
		}else{
			return false;
		}

	}

	function updateCancelbyCon($data){
		$con = dbConnection();
		$sql = "update queueinitialize set queueStatus='Cancelled' where queueId='{$data}'";
		$result = mysqli_query($con, $sql);
		if ($result) {
			return true;
		}else{
			return false;
		}
	}

	function updateAppQueueOnCancel($data){

		$con = dbConnection();
		$sql = "update appqueue set pApStatus='Cancelled' where appId='{$data}'";
		$result = mysqli_query($con, $sql);
		if ($result) {
			return true;
		}else{
			return false;
		}

	}

	function getNotiForP($data){
		$con = dbConnection();
		$sql = "select * from pnotify where pid='{$data}' order by n_id desc";
		$result = mysqli_query($con, $sql);
		$c = [];
		if ($result) {
			while($row = mysqli_fetch_assoc($result)){
			array_push($c, $row);
		};
		return $c;
		}else{
			return false;
		}
	}

	function notificationThree($data){
		$con = dbConnection();
		$sql = "select count(*) from pnotify where pid='{$data}' and openStat='unseen'";
		$result = mysqli_query($con, $sql);
		if ($result) {
			$row = mysqli_fetch_assoc($result);
			return $row;
		}else{
			return false;
		}

	}

	function notificationTwo($data){
		
		$con = dbConnection();
		$sql = "update pnotify set openStat='seen' where n_id='{$data}'";
		$result = mysqli_query($con, $sql);
		if ($result) {
			return true;
		}else{
			return false;
		}

	}

	function notificationOne($data){
		$con = dbConnection();
		$sql = "insert into pnotify values('', '{$data['p']}', 'CURDATE()', '{$data['m']}', 'unseen', '{$data['title']}')";
		$result = mysqli_query($con, $sql);
		if ($result) {
			return true;
		}else{
			return false;
		}
	}

	function insertIntoPay($data){
		$con = dbConnection();
		$sql = "insert into patient_payment values('$data', '0', '0', '0')";
		$result = mysqli_query($con, $sql);
		if ($result) {
			return true;
		}else{
			return false;
		}

	}

	function updateAccPay($data){
		$con = dbConnection();
		$sql = "update patient_payment set deb=deb+(select slot_fee from slot where slot_id='{$data['s']}') where pid='{$data['p']}'";
		//changed deb to balance
		$result = mysqli_query($con, $sql);
		if ($result) {
			return true;
		}else{
			return false;
		}

	}

	function listForCancel($data){
		$con = dbConnection();
		$sql = "select * from appqueue where appId='{$data}'";
		$result = mysqli_query($con, $sql);
		$c = [];
		if ($result) {
			while($row = mysqli_fetch_assoc($result)){
			array_push($c, $row);
		};
		return $c;
		}else{
			return false;
		}


	}

	function checkApIsActive($data){
		$con = dbConnection();
		$sql = "select * from queueinitialize where queueDate='{$data['date']}' and queueSlotId='{$data['id']}'";
		$result = mysqli_query($con, $sql);		
		if ($result) {
				$row = mysqli_fetch_assoc($result);
				return $row;
		}else{
			return false;
		}
	}

	function cancelInfo($data){

		$con = dbConnection();
		$sql = "select * from queueinitialize where queueDate='{$data}'"; 
		$result = mysqli_query($con, $sql);
		$c = [];
		if ($result) {
			while($row = mysqli_fetch_assoc($result)){
			array_push($c, $row);
		};
		return $c;
		}else{
			return false;
		}
	}
	

	function cancelForDay($data){

		$con = dbConnection();
		$sql = "update queueinitialize set queueStatus='Cancelled' where queueDate='{$data}'"; 
		$result = mysqli_query($con, $sql);
		if ($result) {
			return true;
		}else{
			return false;
		}

	}
	
	function conNameForLog($data){

		$con = dbConnection();
		$sql = "select * from syscons where ConsID in (select slot_id from slot where slot_id='{$data}')";
		$result = mysqli_query($con, $sql);
		if ($result) {
			
		$row = mysqli_fetch_assoc($result);			
		return $row;

	}else{
		return false;
	}

	}

	function getAllLog($data){

		$con = dbConnection();
		$sql = "select * from appqueue inner join queueinitialize on appqueue.appId=queueinitialize.queueId where appqueue.pid='$data' order by queueinitialize.queueDate desc";
		$result = mysqli_query($con, $sql);
		$c = [];
		if ($result) {
			while($row = mysqli_fetch_assoc($result)){
			array_push($c, $row);
		};
		return $c;
		}else{
			return false;
		}
	}

	function updateArrivalList($data){
		$con = dbConnection();
		$sql = "update doctorarrival set doctor_arrival_stat='{$data['s']}', late_possibility='{$data['l']}', arrival_time=now() where qid='{$data['q']}'";
		$result = mysqli_query($con, $sql);
		if ($result) {
			return true;
		}else{
			return false;
		}
	}

	function viewArrivalList($data){
		$con = dbConnection();
		$sql = "select * from doctorarrival where qid='{$data}'";
		$result = mysqli_query($con, $sql);
		$row = mysqli_fetch_assoc($result);
		if ($result) {
			return $row;
		}else{
			return "error";
		}

	}

	function insertIntoArrivalList($data){
		$con = dbConnection();
		$sql = "insert into doctorarrival values('{$data}', 'Default', '', 'Default', 'Default', 'Default')";
		$result = mysqli_query($con, $sql);
		if ($result) {
			return true;
		}else{
			return false;
		}

	}

	function existInArrival($data){
		$con = dbConnection();
		$sql = "select count(*) from doctorarrival where qid='{$data}'";
		$result = mysqli_query($con, $sql);
		$row = mysqli_fetch_assoc($result);
		if ($result) {
			if ($row['count(*)']>0) {
				return true;
			}else{
				return false;
			}
		}else{
			return false;
		}


	}
	function completedAppForCon($data){

		$con = dbConnection();
		$sql = "select * from slot inner join queueinitialize on slot.slot_id=queueinitialize.queueSlotId 
		        where slot.slot_consId='{$data}'and queueinitialize.queueStatus='Closed' and queueDate>=CURDATE() order by queueinitialize.queueDate ASC";
		$result = mysqli_query($con, $sql);
		$c = [];
		if ($result) {
			while($row = mysqli_fetch_assoc($result)){
			array_push($c, $row);
		};
		return $c;
		}else{
			return false;
		}

	}


	function upcomingAppForCon($data){

		$con = dbConnection();
		$sql = "select * from slot inner join queueinitialize on slot.slot_id=queueinitialize.queueSlotId 
		        where slot.slot_consId='{$data}'and queueinitialize.queueStatus='Active' and queueDate>=CURDATE() order by queueinitialize.queueDate ASC";
		$result = mysqli_query($con, $sql);
		$c = [];
		if ($result) {
			while($row = mysqli_fetch_assoc($result)){
			array_push($c, $row);
		};
		return $c;
		}else{
			return false;
		}

	}

	function getQueueAppByIdCon($data){

		$con = dbConnection();
		$sql = "select * from queueinitialize inner join appqueue on queueinitialize.queueId=appqueue.appId 
		        where queueinitialize.queueId='{$data}'and queueinitialize.queueStatus='Active' order by appqueue.pQueue asc";
		$result = mysqli_query($con, $sql);
		$c = [];
		if ($result) {
			while($row = mysqli_fetch_assoc($result)){
			array_push($c, $row);
		};
		return $c;
		}else{
			return false;
		}
	}

	function getTodayListforCon($data){

		$con = dbConnection();
		$sql = "select * from slot inner join queueinitialize on slot.slot_id=queueinitialize.queueSlotId 
		        where slot.slot_consId='{$data}'and queueinitialize.queueStatus='Active' and queueDate=CURDATE()";
		$result = mysqli_query($con, $sql);
		$c = [];
		if ($result) {
			while($row = mysqli_fetch_assoc($result)){
			array_push($c, $row);
		};
		return $c;
		}else{
			return false;
		}

	}

	function getQueueAppById($data){

		$con = dbConnection();
		$sql = "select * from appqueue inner join queueinitialize on appqueue.appId=queueinitialize.queueId 
		        where appqueue.appId='{$data}'and queueinitialize.queueStatus='Active' order by appqueue.pQueue asc";
		$result = mysqli_query($con, $sql);
		$c = [];
		if ($result) {
			while($row = mysqli_fetch_assoc($result)){
			array_push($c, $row);
		};
		return $c;
		}else{
			return false;
		}
	}

	function getAppForQueue($data){

		$con = dbConnection();
		$sql = "select * from appqueue inner join queueinitialize on appqueue.appId=queueinitialize.queueId 
		        where appqueue.pid='{$data}' and appqueue.pFee='Paid' and queueinitialize.queueStatus='Active' order by queueinitialize.queueDate asc";
		$result = mysqli_query($con, $sql);
		$c = [];
		if ($result) {
			while($row = mysqli_fetch_assoc($result)){
			array_push($c, $row);
		};
		return $c;
		}else{
			return false;
		}


	}

	function getWaitQueue($data){

		$con = dbConnection();
		$sql = "select * from waitqueue left join queueinitialize on waitqueue.app_id=queueinitialize.queueId 
		        union select * from waitqueue right join queueinitialize on waitqueue.app_id=queueinitialize.queueId
		        where waitqueue.p_id='{$data}'";
                // and queueinitialize.queueDate>=trunc(current_date)
		$result = mysqli_query($con, $sql);
		$c = [];
		if ($result) {
			while($row = mysqli_fetch_assoc($result)){
			array_push($c, $row);
		};
		return $c;
		}else{
			return false;
		}

	}

	function removeFromWaitQueue($data){

		$con = dbConnection();
		$sql = "delete from waitqueue where queueID='{$data}'";
		$result = mysqli_query($con, $sql);
		if ($result) {
			return true;
		}else{
			return false;
		}

	}

	function addToWaitQueue($data){
		$con = dbConnection();
		$con = dbConnection();
		$sql = "insert into waitqueue values('', '{$data['qid']}', '{$data['pid']}', 'Unpaid', 'Default', '')";
		$result = mysqli_query($con, $sql);
		if ($result) {
			$last_id = mysqli_insert_id($con);
			return $last_id;
		}else{
			return false;
		}

	}


	function updateAppQueuePayment($data){

		$con = dbConnection();
		$sql = "update appqueue set pFee='Paid' where appId='{$data['ap_id']}' and pid='{$data['pid']}'";
		$result = mysqli_query($con, $sql);
		if ($result) {
			return true;
		}else{
			return false;
		}

	}

	function removeFromQueue($data){

		$con = dbConnection();
		$sql = "delete from appqueue where appId='{$data['ap_id']}' and pQueue='{$data['q']}'  and pid='{$data['pid']}'";
		$result = mysqli_query($con, $sql);
		if ($result) {
			return true;
		}else{
			return false;
		}


	}

	function updateAppQueueIndex($data){

		$con = dbConnection();
		$sql = "update appqueue set pQueue=pQueue - 1 where appId='{$data['ap_id']}' and pQueue>'{$data['q']}' and pQueue>0";
		$result = mysqli_query($con, $sql);
		if ($result) {
			return true;
		}else{
			return false;
		}

	}

	function updateQuanOnCancel($data){
		$con = dbConnection();
		$sql = "update queueinitialize set queueCurQuantity=queueCurQuantity-1 where queueId='{$data['ap_id']}' and queueCurQuantity>0";
		$result = mysqli_query($con, $sql);
		if ($result) {
			return true;
		}else{
			return false;
		}
	}	

	function updateCurQuan($data){
		$con = dbConnection();
		$sql = "update queueinitialize set queueCurQuantity='{$data['q']}' where queueId='{$data['i']}'";
		$result = mysqli_query($con, $sql);
		if ($result) {
			return true;
		}else{
			return false;
		}
	}

	function addToAppQueue($data){

		$con = dbConnection();
		$sql = "insert into appqueue values('{$data['qid']}', '{$data['pid']}', '', '', 'Unpaid', 'Default', '{$data['q']}')";
		$result = mysqli_query($con, $sql);
		if ($result) {
			return true;
		}else{
			return false;
		}
	}

	function getConName($id){

		$con = dbConnection();
		$sql = "select * from syscons where ConsID='{$id}'";
		$result = mysqli_query($con, $sql);
		$row = mysqli_fetch_assoc($result);
		if ($result) {
			return $row['consName'];
		}else{
			return false;
		}

	}

	function getQueueInfo($id){

		$con = dbConnection();
		$sql = "select * from queueinitialize where queueId='{$id}'";
		$result = mysqli_query($con, $sql);
		$row = mysqli_fetch_assoc($result);
		if ($result) {
			return $row;
		}else{
			return false;
		}

	}


	

	function getApId($d, $sid){
		$con = dbConnection();
		$sql = "select queueId from queueinitialize where queueDate='{$d}' and queueSlotId='{$sid}'";
		$result = mysqli_query($con, $sql);
		$row = mysqli_fetch_assoc($result);
		if ($result) {
			return $row['queueId'];
		}else{
			return false;
		}
	}



	function checkLoginDetail($data){
		$con = dbConnection();
		$sql = "select count(patient_Id) from patientreg where patient_Id='{$data['pid']}' and p_pw='{$data['ppw']}'";
		$result = mysqli_query($con, $sql);
		$row = mysqli_fetch_assoc($result);
		if ($result) {
			if ($row['count(patient_Id)']>0) {
				return true;
			}else{
				return fale;
			}
		}else{
			return false;
		}


	}

	function insertPatient($data){
		$con = dbConnection();
		$sql = "insert into patientreg values('', '{$data['fname']}', '{$data['sname']}', '{$data['email']}', '{$data['phone']}', '{$data['zip']}', '{$data['city']}', '{$data['add']}', '{$data['dob']}', '{$data['gen']}', '{$data['pw']}', 'false')";
		$result = mysqli_query($con, $sql);
		if ($result) {
			$last_id = mysqli_insert_id($con);
			return $last_id;
		}else{
			return false;
		}
	}

	function emailCheck($email){
		$con = dbConnection();
		$sql = "select count(p_email) from patientreg where p_email='{$email}'";
		$result = mysqli_query($con, $sql);
		$row = mysqli_fetch_assoc($result);
		if ($result) {
			if ($row['count(p_email)']>0) {
				return false;
			}else{
				return true;
			}
		}else{
			return false;
		}



	}

	function addToQueue($data){
		$con = dbConnection();
		$sql = "insert into queueinitialize values('', '{$data['date']}', '{$data['id']}', '0', '{$data['qmax']}','Active','','')";
		$result = mysqli_query($con, $sql);
		if ($result) {
			return true;
		}else{
			return false;
		}

	}

	function checkAppointmentExists($data){
		$con = dbConnection();
		$sql = "select count(*) from queueinitialize where queueDate='{$data['date']}' and queueSlotId='{$data['id']}'";

		$result = mysqli_query($con, $sql);
		
		if ($result) {

			$row = mysqli_fetch_assoc($result);

			if ($row['count(*)']>0) {
				return true;
			}else{
				return false;
			}
			
		}else{
			return false;
		}

	}

	function getSlotInfo($id){

		$con = dbConnection();
		$sql = "select slot_id from slot where slot_id='{$id}'";

		$result = mysqli_query($con, $sql);
		
		if ($result) {
			return $result;
		}else{
			return false;
		}

	}

	function getAllSlotInfo($id){

		$con = dbConnection();
		$sql = "select * from slot where slot_id='{$id}'";

		$result = mysqli_query($con, $sql);
		
		if ($result) {
			$row = mysqli_fetch_assoc($result);
			return $row;
		}else{
			return false;
		}

	}

	function getDeptName($id){
		$con = dbConnection();
		$sql = "select deptName from sysdept where deptID='{$id}'";
		$result = mysqli_query($con, $sql);
		
		$row = mysqli_fetch_assoc($result);

		if ($result) {
			return $row;
		}else{
			return false;
		}

	}

	function addSlot($data){
		$con = dbConnection();
		$sql = "insert into slot values('', '{$data['day']}', '{$data['start']}', '{$data['end']}', '{$data['max']}','{$data['loc']}','{$data['p']}','{$data['id']}', 'active', '{$data['fee']}')";
		$result = mysqli_query($con, $sql);
		if ($result) {
			return true;
		}else{
			return false;
		}

	}

	function getAllCons(){

		$con = dbConnection();
		$sql = "select * from syscons";
		$result = mysqli_query($con, $sql);
		//$cons =[];
		//while($row = mysqli_fetch_assoc($result)){
		//	array_push($cons, $row);
		//};
		if ($result) {
			return $result;
		}else{
			return false;
		}
	}

	function getInfoForSlot($id){
		$con = dbConnection();
		$sql = "select * from syscons where ConsID
		='{$id}'";
		$result = mysqli_query($con, $sql);

		$row = mysqli_fetch_assoc($result);

		if ($result) {
			return $row;
		}else{
			return false;
		}

	}

	function getInfoForSlotTwo($id){
		$con = dbConnection();
		$sql = "select * from syscons where ConsID
		='{$id}' and consStat=''";
		$result = mysqli_query($con, $sql);

		$row = mysqli_fetch_assoc($result);

		if ($result) {
			return $row;
		}else{
			return false;
		}

	}

	function getInfoForSlotApp($id){
		$con = dbConnection();
		$sql = "select * from slot where slot_consId
		='{$id}'";
		$result = mysqli_query($con, $sql);
        $c =[];
		while($row = mysqli_fetch_assoc($result)){
			array_push($c, $row);
		};
		if ($result) {
			return $c;
		}else{
			return false;
		}
		

	}

	function getInfoForSlotAppTwo($id){
		$con = dbConnection();
		$sql = "select * from slot where slot_consId
		='{$id}' and slot_Status='Active'";
		$result = mysqli_query($con, $sql);
        $c =[];
		while($row = mysqli_fetch_assoc($result)){
			array_push($c, $row);
		};
		if ($result) {
			return $c;
		}else{
			return false;
		}
		

	}


	function addPasswordConsultant($data){
		$con = dbConnection();
		$sql = "insert into conscredentials values('{$data['id']}', '{$data['pw']}', '{$data['pw']}', 'initial')";
		$result = mysqli_query($con, $sql);

		if ($result) {
			return true;
		}else{
			return false;
		}


	}

	function searchCons($name){
		$con = dbConnection();
		$sql = "select * from syscons where consName like '%{$name}%'";
	    $result = mysqli_query($con, $sql);

	    if($result){
	    	return $result;
	    }else{
	    	return false;
	    }
	}

	function validate ($user){
		$con = dbConnection();
		$sql = "select * from admin_table where adminID='{$user['uid']}' and aPassword='{$user['pw']}'";

		$result = mysqli_query($con, $sql);
		$row = mysqli_fetch_assoc($result);

		if(empty($row)){
			return false;
		}

		if(count($row) > 0){
			return true;
		}else{
		    if(empty($row)){
			 return false;
		}
		}
	}

	function getAllDept(){
		$con = dbConnection();
		$sql = "select * from sysdept";
		$result = mysqli_query($con, $sql);
		$department =[];
		while($row = mysqli_fetch_assoc($result)){
			array_push($department, $row);
		};
		return $department;
	}

	function getAllConsForSlot(){
		$con = dbConnection();
		$sql = "select * from syscons";
		$result = mysqli_query($con, $sql);
		$c =[];
		while($row = mysqli_fetch_assoc($result)){
			array_push($c, $row);
		};
		return $c;
	}

	function getAllConsForSlotTwo(){
		$con = dbConnection();
		$sql = "select * from syscons where consStat=''";
		$result = mysqli_query($con, $sql);
		$c =[];
		while($row = mysqli_fetch_assoc($result)){
			array_push($c, $row);
		};
		return $c;
	}


	function insertDept($data){
		$con = dbConnection();
		$sql = "insert into sysdept values('', '{$data}', '0', 'Active')";
		$result = mysqli_query($con, $sql);
		if ($result) {
			return true;
		}else{
			return false;
		}
	}

	function checkDeptExists($data){
		$con = dbConnection();
		$sql = "select count(*) from sysdept where deptName in ('{$data}') ";
		$result = mysqli_query($con, $sql);
		if ($result) {
			$row = mysqli_fetch_assoc($result);
			if ($row['count(*)']>0) {
				return false;
			}else{
				return true;
			}
		}else{
			return false;
		}
	}

	function getAllConsByDept($name){
		$con = dbConnection();
		$sql = "select * from syscons where deptID in (select deptID from sysdept where deptName='{$name}')";
		$result = mysqli_query($con, $sql);
		$c =[];
		while($row = mysqli_fetch_assoc($result)){
			array_push($c, $row);
		};
		return $c;
	}

	function getAllConsByDeptTwo($name){
		$con = dbConnection();
		$sql = "select * from syscons where consStat='' and deptID in (select deptID from sysdept where deptName='{$name}')";
		$result = mysqli_query($con, $sql);
		$c =[];
		while($row = mysqli_fetch_assoc($result)){
			array_push($c, $row);
		};
		return $c;
	}

	function getDeptId($name){
		$con = dbConnection();
		$sql = "select deptID from sysdept where deptName='{$name}'";
		$result = mysqli_query($con, $sql);
		$dept1 =[];
		while($row = mysqli_fetch_assoc($result)){
			array_push($dept1, $row);
		};

		if ($result) {
			return $dept1['0']['deptID'];
		}else{
			return false;
		}
		

	}

	function uploadConsPhoto($data){
		$con = dbConnection();
		$sql = "update syscons set consPhoto='{$data}' where consID=(select max(ConsID) from syscons)";
		$result = mysqli_query($con, $sql);
		if ($result) {
			return true;
		}else{
			return false;
		}
	}

	function getCurrentID(){
		$con = dbConnection();
		//$sql = "select ConsID from syscons where ConsID=(select max(ConsID) from syscons)";
		$sql = "select ConsID from syscons where ConsID=(select max(ConsID) from syscons)";
		$result = mysqli_query($con, $sql);
		$id =[];
		$row = mysqli_fetch_assoc($result);
		if ($result) {
			return $row;
		}else{
			return "error";
		}

	}

	

	function createConsultantAccount($data){
		$con = dbConnection();

		$did = getDeptId($data['dept']);
		
		$sql = "insert into syscons values( '', '{$data['name']}', '{$data['dept']}', '{$data['phone']}', '{$data['email']}', '{$data['address']}', '{$data['dob']}', '{$data['qualification']}', '{$data['exp']}', '{$data['avail']}', '', '{$did}', '', '')";


		if(mysqli_query($con, $sql)){
			return true;
		}else{
			return false;
		}

	}

		function validateConLogin($user){
		$con = dbConnection();
		$sql = "select * from conscredentials where consId='{$user['uid']}' and consPw='{$user['pw']}'";

		$result = mysqli_query($con, $sql);
		$row = mysqli_fetch_assoc($result);

		if(empty($row)){
			return false;
		}

		if(count($row) > 0){
			return true;
		}else{
		    if(empty($row)){
			 return false;
		}
		}
	}
/*
	function adminCheck ($user){
		$con = dbConnection();
		$sql = "select * from empinfo where username='{$user['username']}' and password='{$user['password']}' and type='admin'";

		$result = mysqli_query($con, $sql);
		$row = mysqli_fetch_assoc($result);

		if(count($row) > 0){
			return true;
		}else{
			return false;
		}

	}

	function create($user){
		$con = dbConnection();
		//$check = "select COUNT(email) from users where email={$user['email']}";

		$sql = "insert into empinfo values( '', '{$user['empname']}' ,'{$user['compname']}' ,'{$user['contno']}', '{$user['username']}', '{$user['password']}', 'employee')";


		if(mysqli_query($con, $sql)){
			return true;
		}else{
			return false;
		}
	}

	function createjob($user){
		$con = dbConnection();
		//$check = "select COUNT(email) from users where email={$user['email']}";

		$sql = "insert into jobs values( '', '{$user['cname']}' ,'{$user['title']}' ,'{$user['location']}', '{$user['salary']})";


		if(mysqli_query($con, $sql)){
			return true;
		}else{
			return false;
		}
	}

	function update($user){
		$con = dbConnection();
		$sql = "update empinfo set emp_name='{$user['empname']}', comp_name='{$user['compname']}', contactno='{$user['contno']}', username='{$user['username']}', password='{$user['password']}' where id={$user['id']}";

		if(mysqli_query($con, $sql)){
			return true;
		}else{
			return false;
		}
	}

		function delete($user){
		$con = dbConnection();
		$sql = "delete from empinfo set where id={$user['id']}";

		if(mysqli_query($con, $sql)){
			return true;
		}else{
			return false;
		}
	}*/

?>